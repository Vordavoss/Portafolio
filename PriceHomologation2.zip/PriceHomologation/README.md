# Homologación de precios (XposStore)

Compara los precios de todas las cajas de `dbo.Till`, elige el precio ganador por SKU y tipo de precio (fecha más reciente) y, en modo corrección, actualiza las cajas desactualizadas. Toda la lógica vive en stored procedures; el back solo orquesta las llamadas.

Flujo completo: `FLUJO_HOMOLOGACION_PRECIOS.png`.

## Contenido

| Ruta | Uso |
|---|---|
| `sql/TILL_PRICE_HOMOLOGATION.sql` | Instalar en **todas** las BD de caja (incluida la servidor) |
| `sql/SERVER_PRICE_HOMOLOGATION.sql` | Instalar **solo** en la BD de la caja servidor (`IS_SERVER = 1`) |
| `src/Models.cs` | Clases de opciones y resultado |
| `src/Connections.cs` | `ITillConnectionProvider`, proveedor de ejemplo con plantilla, contexto EF6 |
| `src/PriceHomologationService.cs` | Orquestador (punto de entrada del endpoint y del cron) |
| `FLUJO_HOMOLOGACION_PRECIOS.png` | Diagrama de flujo |

## Instalación

1. Ejecutar `TILL_PRICE_HOMOLOGATION.sql` en cada BD de caja, incluida la servidor.
2. Ejecutar `SERVER_PRICE_HOMOLOGATION.sql` en la BD de la caja servidor.
3. Usar **SSMS** (o `sqlcmd`). DBeaver parte los scripts en cada `;` y rompe los procedures.

Compatible con SQL Server 2012+ / Express y nivel de compatibilidad 100. Los scripts se pueden volver a ejecutar.

**Actualización desde la versión de 6 tablas:** el script del servidor elimina `PRICE_HOMOLOGATION_LOAD`, `PRICE_HOMOLOGATION_TILL`, `PRICE_HOMOLOGATION_COMPARISON`, el `PRICE_HOMOLOGATION_DETAIL` anterior y el procedure `INSERT_HOMOLOGATION_PRICES`, y agrega columnas a `PRICE_HOMOLOGATION_EXECUTION`. `PRICE_HOMOLOGATION_LOG` solo se elimina si está vacía; si tiene datos se conserva y se avisa con un mensaje.

## Stored procedures

### Cada caja

| Procedure | Descripción |
|---|---|
| `GET_HOMOLOGATION_PRICES @PRICE_TYPES` | Precios activos: SKU, AMOUNT, PRICE_TYPE, MODIFIED_DATETIME, CREATED_DATETIME |
| `UPDATE_HOMOLOGATION_PRICES @CHANGES` | Aplica los cambios en una transacción (todo o nada) y regresa el resultado por SKU |

### Caja servidor

| Procedure | Descripción |
|---|---|
| `START_PRICE_HOMOLOGATION` | Toma el lock, crea la ejecución y regresa las cajas. `SKIPPED` si ya hay una en curso |
| `PROCESS_PRICE_HOMOLOGATION` | Recibe los precios de todas las cajas en un TVP, compara y decide UPDATE / REVIEW |
| `GET_HOMOLOGATION_CHANGES` | Precios a actualizar de una caja |
| `INSERT_HOMOLOGATION_RESULTS` | Marca en el detalle el resultado (UPDATED / ERROR) de una caja |
| `END_PRICE_HOMOLOGATION` | Estatus final, contadores y liberación del lock |
| `GET_HOMOLOGATION_REPORT` | Reporte pivote: PRICE_TILLn, DATE_TILLn, WINNING_PRICE, ACTION, RESULT |

## Tablas (solo 2, en la caja servidor)

| Tabla | Contenido | Retención |
|---|---|---|
| `PRICE_HOMOLOGATION_EXECUTION` | Una fila por ejecución: modo, estatus, cajas (`TILL_LIST`), contadores, mensaje | Permanente |
| `PRICE_HOMOLOGATION_DETAIL` | Una fila por SKU × tipo de precio × caja, solo de SKUs con diferencias: precio de la caja, ganador, acción, estatus, error | `UPDATED` / `ERROR`: permanente. Resto: 30 días |

Estatus por fila en `PRICE_HOMOLOGATION_DETAIL`: `OK` (ya tiene el precio ganador), `PENDING` (por actualizar), `REVIEW`, `UPDATED`, `ERROR`.

Tipos tabla (TVP): `TT_PRICE_HOMOLOGATION_PRICE` (servidor, con `CASH_NUMBER`), `TT_PRICE_HOMOLOGATION_RESULT` (servidor), `TT_PRICE_HOMOLOGATION_CHANGE` (cada caja).

## Reglas de negocio

- Las cajas salen de `dbo.Till` y se identifican solo por `CASH_NUMBER` (`NAME` puede cambiar).
- Caja servidor = `IS_SERVER = 1`, aunque tenga `IS_ACTIVE = 0`. Resto de cajas: `IS_ACTIVE = 1`.
- Precio ganador = fecha más reciente por caja (la mayor entre `MODIFIED_DATETIME` y `CREATED_DATETIME`). Las filas actualizadas toman la fecha del ganador.
- SKU faltante en una caja, empate de fecha con precios distintos o precio duplicado = `REVIEW` (solo reporte, nunca se actualiza).
- Si alguna caja está offline o falla, toda la ejecución queda `CANCELED` y no se cambia nada.
- Una sola ejecución a la vez (`sp_getapplock`); una llamada concurrente regresa `SKIPPED`.

## Estatus

| Estatus | Significado |
|---|---|
| `OK` | Terminó sin errores |
| `PARTIAL` | Al menos una caja no se pudo actualizar (se revirtió); ver `PRICE_HOMOLOGATION_DETAIL` (`STATUS = 'ERROR'`) |
| `CANCELED` | Una caja estaba offline; no se cambió nada |
| `SKIPPED` | Había otra ejecución en curso |
| `ERROR` | Error inesperado; la excepción se relanza |

## Integración en el back (.NET Framework 4.5, EF6)

Implementar `ITillConnectionProvider` con el mecanismo de conexión que ya existe:

```csharp
public class XposTillConnectionProvider : ITillConnectionProvider
{
    public string GetServerConnectionString() { /* server till DB */ }
    public string GetTillConnectionString(int cashNumber, string name) { /* DB of till cashNumber */ }
}
```

Endpoint:

```csharp
var service = new PriceHomologationService(new XposTillConnectionProvider(), new PriceHomologationOptions());
PriceHomologationResult result = await service.ExecuteAsync(isReportOnly: true);
```

Cron (síncrono):

```csharp
var result = service.Execute(true);
```

Notas:

- El lock vive en la conexión al servidor; el servicio la mantiene abierta durante toda la ejecución. No usar una conexión compartida que se pueda reutilizar a mitad del proceso.
- `ConnectionTimeoutSeconds` (default 10) define qué tan rápido se detecta una caja offline.
- El modo reporte (`isReportOnly = true`) es el default; el modo corrección se activa explícitamente.
