using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Xpos.PriceHomologation
{
    /// <summary>
    /// Price homologation job between tills (XposStore).
    ///
    /// All the business logic lives in stored procedures. This class only calls
    /// them in order and moves the data between the tills and the server till,
    /// because a database cannot read another till without linked servers.
    ///
    ///   Server till                          Each till
    ///   -----------------------------------  ------------------------------
    ///   1. START_PRICE_HOMOLOGATION
    ///   2.                                   GET_HOMOLOGATION_PRICES
    ///   3. PROCESS_PRICE_HOMOLOGATION        (prices of all tills in one parameter)
    ///   4. (correction mode only)
    ///      GET_HOMOLOGATION_CHANGES
    ///                                        UPDATE_HOMOLOGATION_PRICES
    ///      INSERT_HOMOLOGATION_RESULTS
    ///   5. END_PRICE_HOMOLOGATION
    ///   6. GET_HOMOLOGATION_REPORT
    ///
    /// If a till cannot be reached, the execution is closed with
    /// END_PRICE_HOMOLOGATION @STATUS = 'CANCELED'.
    /// </summary>
    public class PriceHomologationService
    {
        private readonly ITillConnectionProvider _connections;
        private readonly PriceHomologationOptions _options;

        public PriceHomologationService(ITillConnectionProvider connections, PriceHomologationOptions options)
        {
            if (connections == null) throw new ArgumentNullException("connections");
            _connections = connections;
            _options = options ?? new PriceHomologationOptions();
        }

        /// <summary>Synchronous version for code that does not use async (e.g. the cron).</summary>
        public PriceHomologationResult Execute(bool isReportOnly)
        {
            return ExecuteAsync(isReportOnly).GetAwaiter().GetResult();
        }

        public async Task<PriceHomologationResult> ExecuteAsync(bool isReportOnly)
        {
            var result = new PriceHomologationResult();
            result.Mode = isReportOnly ? "REPORT" : "CORRECTION";

            string serverConnectionString = WithTimeout(_connections.GetServerConnectionString());

            using (var server = new PriceHomologationContext(serverConnectionString))
            {
                // Every server procedure runs on this connection: it holds the lock
                DbConnection serverConnection = server.Database.Connection;
                serverConnection.Open();

                // 1. Lock, execution and tills
                var executionId = new SqlParameter("@EXECUTION_ID", SqlDbType.Int) { Direction = ParameterDirection.Output };
                var status = new SqlParameter("@STATUS", SqlDbType.VarChar, 20) { Direction = ParameterDirection.Output };
                var message = new SqlParameter("@MESSAGE", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output };

                DataTable tillTable = Query(serverConnection, "dbo.START_PRICE_HOMOLOGATION",
                    new SqlParameter("@IS_REPORT_ONLY", isReportOnly), executionId, status, message);

                result.ExecutionId = executionId.Value == DBNull.Value ? (int?)null : (int)executionId.Value;
                if ((status.Value as string) == "SKIPPED")
                {
                    result.Status = "SKIPPED";
                    result.Message = message.Value as string;
                    return result;
                }

                try
                {
                    List<Till> tills = GetTills(tillTable, serverConnectionString);
                    result.Tills = tills.Select(t => t.Status).ToList();

                    // 2. Check every till and get its prices (in parallel)
                    await Task.WhenAll(tills.Select(CheckConnectionAsync)).ConfigureAwait(false);
                    if (tills.All(t => t.Status.Status == "ONLINE"))
                        await Task.WhenAll(tills.Select(GetPricesAsync)).ConfigureAwait(false);

                    List<Till> offline = tills.Where(t => t.Status.Status == "OFFLINE").ToList();
                    if (offline.Count > 0)
                    {
                        string cancelMessage = "Connectivity error. Process canceled. " +
                            string.Join(" | ", offline.Select(t => t.Status.Till + ": " + t.Status.Error));
                        End(serverConnection, result, "CANCELED", cancelMessage);
                        return result;
                    }

                    // 3. Comparison, winning price and actions (prices of all tills in one call)
                    DataTable prices = MergePrices(tills);
                    NonQuery(serverConnection, "dbo.PROCESS_PRICE_HOMOLOGATION",
                        new SqlParameter("@EXECUTION_ID", result.ExecutionId.Value),
                        Table("@PRICES", "dbo.TT_PRICE_HOMOLOGATION_PRICE", prices));
                    prices.Dispose();

                    // 4. Correction mode: update each till in its own transaction
                    if (!isReportOnly)
                    {
                        foreach (Till till in tills)
                            UpdateTill(serverConnection, result.ExecutionId.Value, till);
                    }

                    // 5. Close the execution and 6. report
                    End(serverConnection, result, null, null);
                    result.Report = ToRows(Query(serverConnection, "dbo.GET_HOMOLOGATION_REPORT",
                        new SqlParameter("@EXECUTION_ID", result.ExecutionId.Value)));
                }
                catch (Exception ex)
                {
                    try
                    {
                        End(serverConnection, result, "ERROR", ex.Message);
                    }
                    catch
                    {
                        // The original error is the one that matters
                    }
                    throw;
                }
            }
            return result;
        }

        // ---------------------------------------------------------------------
        // Steps
        // ---------------------------------------------------------------------
        private List<Till> GetTills(DataTable tillTable, string serverConnectionString)
        {
            var tills = new List<Till>();
            foreach (DataRow row in tillTable.Rows)
            {
                var till = new Till();
                till.Status = new TillStatus
                {
                    CashNumber = (int)row["CASH_NUMBER"],
                    Till = (string)row["TILL"],
                    Name = row["NAME"] as string,
                    IsServer = (bool)row["IS_SERVER"],
                    Status = "NOT CHECKED"
                };
                try
                {
                    till.ConnectionString = till.Status.IsServer
                        ? serverConnectionString
                        : WithTimeout(_connections.GetTillConnectionString(till.Status.CashNumber, till.Status.Name));
                }
                catch (Exception ex)
                {
                    till.Status.Status = "OFFLINE";
                    till.Status.Error = ex.Message;
                }
                tills.Add(till);
            }
            return tills;
        }

        private async Task CheckConnectionAsync(Till till)
        {
            if (till.Status.Status == "OFFLINE") return;
            try
            {
                using (var connection = new SqlConnection(till.ConnectionString))
                {
                    await connection.OpenAsync().ConfigureAwait(false);
                }
                till.Status.Status = "ONLINE";
            }
            catch (Exception ex)
            {
                till.Status.Status = "OFFLINE";
                till.Status.Error = ex.Message;
            }
        }

        private async Task GetPricesAsync(Till till)
        {
            try
            {
                using (var context = new PriceHomologationContext(till.ConnectionString))
                {
                    DbConnection connection = context.Database.Connection;
                    await connection.OpenAsync().ConfigureAwait(false);
                    till.Prices = await QueryAsync(connection, "dbo.GET_HOMOLOGATION_PRICES",
                        new SqlParameter("@PRICE_TYPES", _options.PriceTypes)).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                till.Status.Status = "OFFLINE";
                till.Status.Error = ex.Message;
            }
        }

        /// <summary>
        /// Joins the prices of every till in one table with the structure of
        /// TT_PRICE_HOMOLOGATION_PRICE: CASH_NUMBER + the columns of GET_HOMOLOGATION_PRICES.
        /// </summary>
        private static DataTable MergePrices(List<Till> tills)
        {
            var prices = new DataTable();
            prices.Columns.Add("CASH_NUMBER", typeof(int));
            prices.Columns.Add("SKU", typeof(string));
            prices.Columns.Add("AMOUNT", typeof(decimal));
            prices.Columns.Add("PRICE_TYPE", typeof(string));
            prices.Columns.Add("MODIFIED_DATETIME", typeof(DateTime));
            prices.Columns.Add("CREATED_DATETIME", typeof(DateTime));

            prices.BeginLoadData();
            foreach (Till till in tills)
            {
                foreach (DataRow row in till.Prices.Rows)
                {
                    prices.Rows.Add(till.Status.CashNumber, row["SKU"], row["AMOUNT"], row["PRICE_TYPE"],
                        row["MODIFIED_DATETIME"], row["CREATED_DATETIME"]);
                }
                till.Prices = null;
            }
            prices.EndLoadData();
            return prices;
        }

        private void UpdateTill(DbConnection serverConnection, int executionId, Till till)
        {
            DataTable changes = Query(serverConnection, "dbo.GET_HOMOLOGATION_CHANGES",
                new SqlParameter("@EXECUTION_ID", executionId),
                new SqlParameter("@CASH_NUMBER", till.Status.CashNumber));
            if (changes.Rows.Count == 0) return;

            DataTable results;
            try
            {
                using (var context = new PriceHomologationContext(till.ConnectionString))
                {
                    DbConnection connection = context.Database.Connection;
                    connection.Open();
                    results = Query(connection, "dbo.UPDATE_HOMOLOGATION_PRICES",
                        Table("@CHANGES", "dbo.TT_PRICE_HOMOLOGATION_CHANGE", changes));
                }
            }
            catch (Exception ex)
            {
                // The till rolled back everything: every change of this till failed
                results = ErrorResults(changes, ex.Message);
            }

            NonQuery(serverConnection, "dbo.INSERT_HOMOLOGATION_RESULTS",
                new SqlParameter("@EXECUTION_ID", executionId),
                new SqlParameter("@CASH_NUMBER", till.Status.CashNumber),
                Table("@RESULTS", "dbo.TT_PRICE_HOMOLOGATION_RESULT", results));
        }

        private void End(DbConnection serverConnection, PriceHomologationResult result, string status, string message)
        {
            if (result.ExecutionId == null) return;

            DataTable summary = Query(serverConnection, "dbo.END_PRICE_HOMOLOGATION",
                new SqlParameter("@EXECUTION_ID", result.ExecutionId.Value),
                new SqlParameter("@STATUS", (object)status ?? DBNull.Value),
                new SqlParameter("@MESSAGE", (object)Truncate(message, 4000) ?? DBNull.Value));

            if (summary.Rows.Count == 0) return;
            DataRow row = summary.Rows[0];
            result.Status = row["STATUS"] as string;
            result.Message = row["MESSAGE"] as string;
            result.DifferentSkus = ToInt(row["DIFFERENT_SKUS"]);
            result.SkusToUpdate = ToInt(row["SKUS_TO_UPDATE"]);
            result.SkusToReview = ToInt(row["SKUS_TO_REVIEW"]);
            result.SkusWithError = ToInt(row["SKUS_WITH_ERROR"]);
        }

        // ---------------------------------------------------------------------
        // Stored procedure calls
        // ---------------------------------------------------------------------
        private DataTable Query(DbConnection connection, string procedure, params SqlParameter[] parameters)
        {
            using (DbCommand command = CreateCommand(connection, procedure, parameters))
            using (DbDataReader reader = command.ExecuteReader())
            {
                var table = new DataTable();
                table.Load(reader);
                return table;
            }
        }

        private async Task<DataTable> QueryAsync(DbConnection connection, string procedure, params SqlParameter[] parameters)
        {
            using (DbCommand command = CreateCommand(connection, procedure, parameters))
            using (DbDataReader reader = await command.ExecuteReaderAsync().ConfigureAwait(false))
            {
                var table = new DataTable();
                table.Load(reader);
                return table;
            }
        }

        private void NonQuery(DbConnection connection, string procedure, params SqlParameter[] parameters)
        {
            using (DbCommand command = CreateCommand(connection, procedure, parameters))
            {
                command.ExecuteNonQuery();
            }
        }

        private DbCommand CreateCommand(DbConnection connection, string procedure, SqlParameter[] parameters)
        {
            DbCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = procedure;
            command.CommandTimeout = _options.CommandTimeoutSeconds;
            command.Parameters.AddRange(parameters);
            return command;
        }

        private static SqlParameter Table(string name, string typeName, DataTable value)
        {
            return new SqlParameter(name, SqlDbType.Structured) { TypeName = typeName, Value = value };
        }

        // ---------------------------------------------------------------------
        // Helpers
        // ---------------------------------------------------------------------
        private string WithTimeout(string connectionString)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new InvalidOperationException("There is no connection string for this till.");
            var builder = new SqlConnectionStringBuilder(connectionString);
            builder.ConnectTimeout = _options.ConnectionTimeoutSeconds;
            return builder.ConnectionString;
        }

        private static DataTable ErrorResults(DataTable changes, string error)
        {
            var results = new DataTable();
            results.Columns.Add("SKU", typeof(string));
            results.Columns.Add("PRICE_TYPE", typeof(string));
            results.Columns.Add("STATUS", typeof(string));
            results.Columns.Add("ERROR_MESSAGE", typeof(string));
            foreach (DataRow change in changes.Rows)
                results.Rows.Add(change["SKU"], change["PRICE_TYPE"], "ERROR", Truncate(error, 4000));
            return results;
        }

        private static List<Dictionary<string, object>> ToRows(DataTable table)
        {
            var rows = new List<Dictionary<string, object>>();
            foreach (DataRow row in table.Rows)
            {
                var item = new Dictionary<string, object>();
                foreach (DataColumn column in table.Columns)
                    item[column.ColumnName] = row[column] == DBNull.Value ? null : row[column];
                rows.Add(item);
            }
            return rows;
        }

        private static int ToInt(object value)
        {
            return value == null || value == DBNull.Value ? 0 : Convert.ToInt32(value);
        }

        private static string Truncate(string text, int length)
        {
            return text == null || text.Length <= length ? text : text.Substring(0, length);
        }

        private class Till
        {
            public TillStatus Status { get; set; }
            public string ConnectionString { get; set; }
            public DataTable Prices { get; set; }
        }
    }
}
