using System;
using System.Collections.Generic;

namespace Xpos.PriceHomologation
{
    /// <summary>Job settings.</summary>
    public class PriceHomologationOptions
    {
        public PriceHomologationOptions()
        {
            PriceTypes = "SALE_PRICE";
            ConnectionTimeoutSeconds = 10;
            CommandTimeoutSeconds = 300;
        }

        /// <summary>Comma-separated price types to compare (code.NAME).</summary>
        public string PriceTypes { get; set; }

        /// <summary>Maximum time to connect to a till. An offline till is detected within this time.</summary>
        public int ConnectionTimeoutSeconds { get; set; }

        /// <summary>Maximum time for each stored procedure call.</summary>
        public int CommandTimeoutSeconds { get; set; }
    }

    /// <summary>Result of one execution. This is what the endpoint returns.</summary>
    public class PriceHomologationResult
    {
        public PriceHomologationResult()
        {
            Tills = new List<TillStatus>();
            Report = new List<Dictionary<string, object>>();
        }

        public int? ExecutionId { get; set; }
        public string Mode { get; set; }             // REPORT / CORRECTION
        public string Status { get; set; }           // OK / PARTIAL / CANCELED / SKIPPED / ERROR
        public string Message { get; set; }
        public int DifferentSkus { get; set; }
        public int SkusToUpdate { get; set; }
        public int SkusToReview { get; set; }
        public int SkusWithError { get; set; }
        public List<TillStatus> Tills { get; set; }

        /// <summary>
        /// Rows of GET_HOMOLOGATION_REPORT: SKU, PRICE_TYPE, PRICE_TILLn, PRICE_STATUS,
        /// DATE_TILLn, WINNING_PRICE, WINNING_TILL, WINNING_DATE, ACTION, RESULT.
        /// </summary>
        public List<Dictionary<string, object>> Report { get; set; }
    }

    public class TillStatus
    {
        public int CashNumber { get; set; }
        public string Till { get; set; }             // 'TILL' + CASH_NUMBER
        public string Name { get; set; }             // NAME in Till, informative only
        public bool IsServer { get; set; }
        public string Status { get; set; }           // ONLINE / OFFLINE / NOT CHECKED
        public string Error { get; set; }
    }
}
