using System;
using System.Data.Entity;

namespace Xpos.PriceHomologation
{
    /// <summary>
    /// Tells where the database of each till is. Implement it with the connection
    /// mechanism the back end already has.
    /// </summary>
    public interface ITillConnectionProvider
    {
        /// <summary>Connection string to the server till database.</summary>
        string GetServerConnectionString();

        /// <summary>
        /// Connection string to the database of a till. The till is identified by
        /// CASH_NUMBER; the name (NAME in Till) may change and is informative only.
        /// </summary>
        string GetTillConnectionString(int cashNumber, string name);
    }

    /// <summary>
    /// Simple implementation with a template: {n} is replaced by CASH_NUMBER.
    /// Test example: "Data Source=.\SQLEXPRESS;Initial Catalog=XposStore_50LP1_v{n};..."
    /// </summary>
    public class TemplateTillConnectionProvider : ITillConnectionProvider
    {
        private readonly string _serverConnectionString;
        private readonly string _tillTemplate;

        public TemplateTillConnectionProvider(string serverConnectionString, string tillTemplate)
        {
            if (string.IsNullOrEmpty(serverConnectionString)) throw new ArgumentNullException("serverConnectionString");
            if (string.IsNullOrEmpty(tillTemplate)) throw new ArgumentNullException("tillTemplate");
            _serverConnectionString = serverConnectionString;
            _tillTemplate = tillTemplate;
        }

        public string GetServerConnectionString()
        {
            return _serverConnectionString;
        }

        public string GetTillConnectionString(int cashNumber, string name)
        {
            return _tillTemplate.Replace("{n}", cashNumber.ToString());
        }
    }

    /// <summary>
    /// EF6 context without a model: it is only used to call stored procedures.
    /// It never creates or validates the database.
    /// </summary>
    public class PriceHomologationContext : DbContext
    {
        static PriceHomologationContext()
        {
            Database.SetInitializer<PriceHomologationContext>(null);
        }

        public PriceHomologationContext(string connectionString)
            : base(connectionString)
        {
        }
    }
}
