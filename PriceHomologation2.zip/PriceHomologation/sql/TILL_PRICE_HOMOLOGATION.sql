/* =============================================================================
   PRICE HOMOLOGATION - TILL OBJECTS
   -----------------------------------------------------------------------------
   Install in the XposStore database of EVERY till, including the server till.
   Compatible with SQL Server 2012 or later and compatibility level 100 or later.

   Objects:
     - TT_PRICE_HOMOLOGATION_CHANGE   Table type: price changes to apply.
     - GET_HOMOLOGATION_PRICES        Returns the active prices of this till.
     - UPDATE_HOMOLOGATION_PRICES     Applies price changes in one transaction.
   ============================================================================= */

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF TYPE_ID(N'dbo.TT_PRICE_HOMOLOGATION_CHANGE') IS NULL
    CREATE TYPE dbo.TT_PRICE_HOMOLOGATION_CHANGE AS TABLE (
        SKU               VARCHAR(100)  NOT NULL,
        PRICE_TYPE        VARCHAR(50)   NOT NULL,
        AMOUNT            DECIMAL(16,4) NOT NULL,   -- winning price
        MODIFIED_DATETIME DATETIME      NULL,       -- winning price date
        PRIMARY KEY (SKU, PRICE_TYPE)
    );
GO


/* -----------------------------------------------------------------------------
   GET_HOMOLOGATION_PRICES
   Returns the active prices of the active product items of this till.
   @PRICE_TYPES: comma-separated list of price types (code.NAME).
   The column order matches TT_PRICE_HOMOLOGATION_PRICE on the server till.
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.GET_HOMOLOGATION_PRICES') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.GET_HOMOLOGATION_PRICES AS RETURN 0;');
GO
ALTER PROCEDURE dbo.GET_HOMOLOGATION_PRICES
    @PRICE_TYPES VARCHAR(1000) = 'SALE_PRICE'
AS
BEGIN
    SET NOCOUNT ON;

    SELECT i.SKU,
           p.AMOUNT,
           pt.NAME AS PRICE_TYPE,
           p.modified_datetime AS MODIFIED_DATETIME,
           p.created_datetime AS CREATED_DATETIME
    FROM dbo.item AS i
    INNER JOIN dbo.ITEM_BUSINESS_UNIT_LINK AS il ON il.ITEM_ID = i.ITEM_ID
    INNER JOIN dbo.PRICE AS p ON p.ITEM_BUSINESS_UNIT_LINK_ID = il.ITEM_BUSINESS_UNIT_LINK_ID
    INNER JOIN dbo.code AS pt ON pt.CODE_ID = p.PRICE_TYPE_CODE_ID
    INNER JOIN dbo.code AS it ON it.CODE_ID = i.ITEM_TYPE_CODE_ID
    WHERE i.IS_ACTIVE = 1
      AND p.IS_ACTIVE = 1
      AND it.NAME = 'PRODUCT_ITEM'
      AND ',' + REPLACE(@PRICE_TYPES, ' ', '') + ',' LIKE '%,' + pt.NAME + ',%';
END
GO


/* -----------------------------------------------------------------------------
   UPDATE_HOMOLOGATION_PRICES
   Applies the winning price and date to each SKU / price type in @CHANGES.
   All changes are applied in a single transaction: if a SKU matches more than
   one active price, or any error occurs, nothing is changed in this till.
   Returns one row per change. The column order matches
   TT_PRICE_HOMOLOGATION_RESULT on the server till.
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.UPDATE_HOMOLOGATION_PRICES') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.UPDATE_HOMOLOGATION_PRICES AS RETURN 0;');
GO
ALTER PROCEDURE dbo.UPDATE_HOMOLOGATION_PRICES
    @CHANGES dbo.TT_PRICE_HOMOLOGATION_CHANGE READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @UPDATED TABLE (SKU VARCHAR(100), PRICE_TYPE VARCHAR(50));

    BEGIN TRANSACTION;

    UPDATE p
       SET p.AMOUNT = c.AMOUNT,
           p.modified_datetime = ISNULL(c.MODIFIED_DATETIME, p.modified_datetime)
    OUTPUT c.SKU, c.PRICE_TYPE INTO @UPDATED (SKU, PRICE_TYPE)
    FROM @CHANGES AS c
    INNER JOIN dbo.item AS i ON i.SKU = c.SKU
    INNER JOIN dbo.ITEM_BUSINESS_UNIT_LINK AS il ON il.ITEM_ID = i.ITEM_ID
    INNER JOIN dbo.PRICE AS p ON p.ITEM_BUSINESS_UNIT_LINK_ID = il.ITEM_BUSINESS_UNIT_LINK_ID
    INNER JOIN dbo.code AS pt ON pt.CODE_ID = p.PRICE_TYPE_CODE_ID AND pt.NAME = c.PRICE_TYPE
    INNER JOIN dbo.code AS it ON it.CODE_ID = i.ITEM_TYPE_CODE_ID
    WHERE i.IS_ACTIVE = 1
      AND p.IS_ACTIVE = 1
      AND it.NAME = 'PRODUCT_ITEM';

    IF EXISTS (SELECT 1 FROM @UPDATED GROUP BY SKU, PRICE_TYPE HAVING COUNT(*) > 1)
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50010, N'A SKU matched more than one active price. All changes for this till were rolled back.', 1;
    END

    COMMIT TRANSACTION;

    SELECT c.SKU,
           c.PRICE_TYPE,
           CASE WHEN u.SKU IS NULL THEN 'ERROR' ELSE 'UPDATED' END AS STATUS,
           CASE WHEN u.SKU IS NULL THEN N'Price not found.' END AS ERROR_MESSAGE
    FROM @CHANGES AS c
    LEFT JOIN (SELECT DISTINCT SKU, PRICE_TYPE FROM @UPDATED) AS u
           ON u.SKU = c.SKU AND u.PRICE_TYPE = c.PRICE_TYPE;
END
GO
