/* =============================================================================
   PRICE HOMOLOGATION - SERVER TILL OBJECTS
   -----------------------------------------------------------------------------
   Install in the XposStore database of the server till (IS_SERVER = 1 in Till),
   after TILL_PRICE_HOMOLOGATION.sql (the server till is also a till).
   Compatible with SQL Server 2012 or later and compatibility level 100 or later.

   Tables (only two):
     PRICE_HOMOLOGATION_EXECUTION   One row per execution (permanent).
     PRICE_HOMOLOGATION_DETAIL      One row per SKU, price type and till, only for
                                    the SKUs with differences. It is the report and
                                    the audit log. Rows UPDATED / ERROR are kept;
                                    the rest are purged after 30 days.

   The back end orchestrates one execution by calling, in this order:
     1. START_PRICE_HOMOLOGATION        Lock, execution record and tills from Till.
     2. GET_HOMOLOGATION_PRICES         (on each till) Active prices.
     3. PROCESS_PRICE_HOMOLOGATION      Receives the prices of all tills in one
                                        parameter, compares them, picks the winning
                                        price and decides the action.
     4. Correction mode only, for each till:
        GET_HOMOLOGATION_CHANGES        Prices to update in the till.
        UPDATE_HOMOLOGATION_PRICES      (on the till) Applies them.
        INSERT_HOMOLOGATION_RESULTS     Saves the result in the detail.
     5. END_PRICE_HOMOLOGATION          Summary and lock release.
     6. GET_HOMOLOGATION_REPORT         Table of what would change (or changed).

   If a till cannot be reached, the back end calls END_PRICE_HOMOLOGATION with
   @STATUS = 'CANCELED' and the whole process is canceled.

   Business rules:
     - Tills come from dbo.Till: the server till is IS_SERVER = 1 (even if it is
       inactive) and the other tills are IS_ACTIVE = 1. Tills are identified by
       CASH_NUMBER only; NAME may change and is informative.
     - Winning price: the most recent date between created and modified.
     - Not updated, marked for review: SKU missing in a till, date tie with
       different prices, more than one active price for the same SKU in a till.
     - The updated price gets the date of the winning price.
   ============================================================================= */

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* -----------------------------------------------------------------------------
   Upgrade from the previous version (six tables). Safe to run on a new database.
   The old log is dropped only when it is empty.
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.INSERT_HOMOLOGATION_PRICES') IS NOT NULL
    DROP PROCEDURE dbo.INSERT_HOMOLOGATION_PRICES;
IF OBJECT_ID(N'dbo.PRICE_HOMOLOGATION_LOAD') IS NOT NULL
    DROP TABLE dbo.PRICE_HOMOLOGATION_LOAD;
IF OBJECT_ID(N'dbo.PRICE_HOMOLOGATION_TILL') IS NOT NULL
    DROP TABLE dbo.PRICE_HOMOLOGATION_TILL;
IF OBJECT_ID(N'dbo.PRICE_HOMOLOGATION_COMPARISON') IS NOT NULL
    DROP TABLE dbo.PRICE_HOMOLOGATION_COMPARISON;
IF COL_LENGTH(N'dbo.PRICE_HOMOLOGATION_DETAIL', N'REFERENCE_DATE') IS NOT NULL
    DROP TABLE dbo.PRICE_HOMOLOGATION_DETAIL;
GO
IF OBJECT_ID(N'dbo.PRICE_HOMOLOGATION_LOG') IS NOT NULL
BEGIN
    IF NOT EXISTS (SELECT 1 FROM dbo.PRICE_HOMOLOGATION_LOG)
        DROP TABLE dbo.PRICE_HOMOLOGATION_LOG;
    ELSE
        PRINT 'dbo.PRICE_HOMOLOGATION_LOG (previous version) has rows and was kept. Drop it manually when it is no longer needed.';
END
GO
IF TYPE_ID(N'dbo.TT_PRICE_HOMOLOGATION_PRICE') IS NOT NULL
   AND NOT EXISTS (SELECT 1
                   FROM sys.table_types AS tt
                   JOIN sys.columns AS c ON c.object_id = tt.type_table_object_id
                   WHERE tt.name = N'TT_PRICE_HOMOLOGATION_PRICE' AND c.name = N'CASH_NUMBER')
BEGIN
    IF OBJECT_ID(N'dbo.PROCESS_PRICE_HOMOLOGATION') IS NOT NULL
        DROP PROCEDURE dbo.PROCESS_PRICE_HOMOLOGATION;
    DROP TYPE dbo.TT_PRICE_HOMOLOGATION_PRICE;
END
GO

/* -----------------------------------------------------------------------------
   Tables
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.PRICE_HOMOLOGATION_EXECUTION') IS NULL
    CREATE TABLE dbo.PRICE_HOMOLOGATION_EXECUTION (
        EXECUTION_ID       INT IDENTITY(1,1) PRIMARY KEY,
        EXECUTION_DATE     DATETIME       NOT NULL DEFAULT GETDATE(),
        END_DATE           DATETIME       NULL,
        MODE               VARCHAR(10)    NOT NULL,   -- REPORT / CORRECTION
        STATUS             VARCHAR(20)    NOT NULL,   -- RUNNING / OK / PARTIAL / CANCELED / SKIPPED / ERROR
        TILLS              INT            NULL,
        TILL_LIST          VARCHAR(500)   NULL,       -- CASH_NUMBER of the tills, e.g. '1,2,3'
        SERVER_CASH_NUMBER INT            NULL,
        DIFFERENT_SKUS     INT            NULL,
        SKUS_TO_UPDATE     INT            NULL,
        SKUS_TO_REVIEW     INT            NULL,
        SKUS_WITH_ERROR    INT            NULL,
        MESSAGE            NVARCHAR(4000) NULL
    );
GO
-- Columns added in this version (existing installations)
IF COL_LENGTH(N'dbo.PRICE_HOMOLOGATION_EXECUTION', N'TILL_LIST') IS NULL
    ALTER TABLE dbo.PRICE_HOMOLOGATION_EXECUTION ADD TILL_LIST VARCHAR(500) NULL;
IF COL_LENGTH(N'dbo.PRICE_HOMOLOGATION_EXECUTION', N'SERVER_CASH_NUMBER') IS NULL
    ALTER TABLE dbo.PRICE_HOMOLOGATION_EXECUTION ADD SERVER_CASH_NUMBER INT NULL;
GO

-- One row per SKU, price type and till, only for the SKUs with differences
IF OBJECT_ID(N'dbo.PRICE_HOMOLOGATION_DETAIL') IS NULL
    CREATE TABLE dbo.PRICE_HOMOLOGATION_DETAIL (
        EXECUTION_ID  INT            NOT NULL,
        SKU           VARCHAR(100)   NOT NULL,
        PRICE_TYPE    VARCHAR(50)    NOT NULL,
        CASH_NUMBER   INT            NOT NULL,
        PRICE_ROWS    INT            NOT NULL,   -- 0 = missing, 1 = normal, >1 = duplicated
        PRICE         DECIMAL(16,4)  NULL,       -- price in the till (previous price if updated)
        PRICE_DATE    DATETIME       NULL,       -- most recent between created and modified
        WINNING_PRICE DECIMAL(16,4)  NULL,
        WINNING_TILL  VARCHAR(200)   NULL,       -- e.g. 'TILL1,TILL2'
        WINNING_DATE  DATETIME       NULL,
        ACTION        VARCHAR(1000)  NULL,       -- e.g. 'UPDATE TILL3 TO $2.00'
        STATUS        VARCHAR(20)    NOT NULL,   -- OK / PENDING / REVIEW / UPDATED / ERROR
        ERROR_MESSAGE NVARCHAR(4000) NULL,
        UPDATE_DATE   DATETIME       NULL,
        CONSTRAINT PK_PRICE_HOMOLOGATION_DETAIL PRIMARY KEY (EXECUTION_ID, SKU, PRICE_TYPE, CASH_NUMBER)
    );
GO

/* -----------------------------------------------------------------------------
   Table types
   ----------------------------------------------------------------------------- */
-- CASH_NUMBER + the columns of GET_HOMOLOGATION_PRICES, in the same order
IF TYPE_ID(N'dbo.TT_PRICE_HOMOLOGATION_PRICE') IS NULL
    CREATE TYPE dbo.TT_PRICE_HOMOLOGATION_PRICE AS TABLE (
        CASH_NUMBER       INT           NOT NULL,
        SKU               VARCHAR(100)  NOT NULL,
        AMOUNT            DECIMAL(16,4) NULL,
        PRICE_TYPE        VARCHAR(50)   NOT NULL,
        MODIFIED_DATETIME DATETIME      NULL,
        CREATED_DATETIME  DATETIME      NULL
    );

-- Same columns and order as the result of UPDATE_HOMOLOGATION_PRICES
IF TYPE_ID(N'dbo.TT_PRICE_HOMOLOGATION_RESULT') IS NULL
    CREATE TYPE dbo.TT_PRICE_HOMOLOGATION_RESULT AS TABLE (
        SKU           VARCHAR(100)   NOT NULL,
        PRICE_TYPE    VARCHAR(50)    NOT NULL,
        STATUS        VARCHAR(20)    NOT NULL,   -- UPDATED / ERROR
        ERROR_MESSAGE NVARCHAR(4000) NULL
    );
GO


/* -----------------------------------------------------------------------------
   START_PRICE_HOMOLOGATION
   Takes the lock, creates the execution and returns the tills that take part.
   The lock belongs to the caller's connection: the back end must call every
   server procedure of the execution on that same connection. The lock is
   released by END_PRICE_HOMOLOGATION or when the connection is closed.
   If another execution is running: @STATUS = 'SKIPPED' and no tills are returned.
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.START_PRICE_HOMOLOGATION') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.START_PRICE_HOMOLOGATION AS RETURN 0;');
GO
ALTER PROCEDURE dbo.START_PRICE_HOMOLOGATION
    @IS_REPORT_ONLY BIT = 1,
    @EXECUTION_ID   INT            = NULL OUTPUT,
    @STATUS         VARCHAR(20)    = NULL OUTPUT,
    @MESSAGE        NVARCHAR(4000) = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @MODE        VARCHAR(10) = CASE WHEN @IS_REPORT_ONLY = 1 THEN 'REPORT' ELSE 'CORRECTION' END,
            @LOCK        INT,
            @SERVER_CASH INT,
            @TILL_DETAIL NVARCHAR(MAX);

    SELECT @EXECUTION_ID = NULL, @STATUS = NULL, @MESSAGE = NULL;

    CREATE TABLE #TILLS (
        CASH_NUMBER INT          NOT NULL,
        TILL        VARCHAR(20)  NOT NULL,   -- 'TILL' + CASH_NUMBER
        NAME        VARCHAR(100) NULL,       -- informative only
        IS_SERVER   BIT          NOT NULL
    );

    -- Lock: only one execution at a time
    EXEC @LOCK = sp_getapplock @Resource    = N'PRICE_HOMOLOGATION',
                               @LockMode    = N'Exclusive',
                               @LockOwner   = N'Session',
                               @LockTimeout = 0;
    IF @LOCK < 0
    BEGIN
        SELECT @STATUS = 'SKIPPED', @MESSAGE = N'Another execution is already running.';
        INSERT dbo.PRICE_HOMOLOGATION_EXECUTION (MODE, STATUS, END_DATE, MESSAGE)
        VALUES (@MODE, @STATUS, GETDATE(), @MESSAGE);
        SET @EXECUTION_ID = SCOPE_IDENTITY();

        SELECT CASH_NUMBER, TILL, NAME, IS_SERVER FROM #TILLS;
        RETURN;
    END

    BEGIN TRY
        -- Purge: rows that were not updated, older than 30 days
        DELETE d
        FROM dbo.PRICE_HOMOLOGATION_DETAIL AS d
        JOIN dbo.PRICE_HOMOLOGATION_EXECUTION AS e ON e.EXECUTION_ID = d.EXECUTION_ID
        WHERE e.EXECUTION_DATE < DATEADD(DAY, -30, GETDATE())
          AND d.STATUS NOT IN ('UPDATED', 'ERROR');

        INSERT dbo.PRICE_HOMOLOGATION_EXECUTION (MODE, STATUS) VALUES (@MODE, 'RUNNING');
        SET @EXECUTION_ID = SCOPE_IDENTITY();

        -- Till content for error messages
        SET @TILL_DETAIL = N' Database: ' + DB_NAME() + N'. Till: ' + ISNULL(STUFF((
            SELECT N' | CASH_NUMBER=' + ISNULL(CAST(CASH_NUMBER AS NVARCHAR(10)), N'NULL')
                 + N' NAME=' + ISNULL(NAME, N'NULL')
                 + N' IS_ACTIVE=' + ISNULL(CAST(IS_ACTIVE AS NVARCHAR(1)), N'NULL')
                 + N' IS_SERVER=' + ISNULL(CAST(IS_SERVER AS NVARCHAR(1)), N'NULL')
            FROM dbo.Till ORDER BY CASH_NUMBER
            FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 3, N''), N'(empty)');

        -- Server till: the only one with IS_SERVER = 1 (if there are several, the active one)
        IF (SELECT COUNT(*) FROM dbo.Till WHERE IS_SERVER = 1) = 1
            SET @SERVER_CASH = (SELECT CASH_NUMBER FROM dbo.Till WHERE IS_SERVER = 1);
        ELSE IF (SELECT COUNT(*) FROM dbo.Till WHERE IS_SERVER = 1 AND IS_ACTIVE = 1) = 1
            SET @SERVER_CASH = (SELECT CASH_NUMBER FROM dbo.Till WHERE IS_SERVER = 1 AND IS_ACTIVE = 1);

        IF @SERVER_CASH IS NULL
        BEGIN
            SET @MESSAGE = N'Could not identify the server till in Till (IS_SERVER = 1).'
                         + N' Check that these objects are installed in the server till database.'
                         + @TILL_DETAIL;
            THROW 50001, @MESSAGE, 1;
        END

        -- Tills that take part: the server till and the other active tills
        INSERT #TILLS (CASH_NUMBER, TILL, NAME, IS_SERVER)
        SELECT t.CASH_NUMBER,
               'TILL' + CAST(t.CASH_NUMBER AS VARCHAR(10)),
               LTRIM(RTRIM(t.NAME)),
               CASE WHEN t.CASH_NUMBER = @SERVER_CASH AND t.IS_SERVER = 1 THEN 1 ELSE 0 END
        FROM dbo.Till AS t
        WHERE (t.CASH_NUMBER = @SERVER_CASH AND t.IS_SERVER = 1)
           OR (t.IS_ACTIVE = 1 AND ISNULL(t.IS_SERVER, 0) = 0);

        IF EXISTS (SELECT CASH_NUMBER FROM #TILLS GROUP BY CASH_NUMBER HAVING COUNT(*) > 1)
        BEGIN
            SET @MESSAGE = N'Till has duplicated CASH_NUMBER values among the active tills.' + @TILL_DETAIL;
            THROW 50002, @MESSAGE, 1;
        END

        IF (SELECT COUNT(*) FROM #TILLS) < 2
        BEGIN
            SET @MESSAGE = N'At least two active tills are required in Till.' + @TILL_DETAIL;
            THROW 50003, @MESSAGE, 1;
        END

        UPDATE dbo.PRICE_HOMOLOGATION_EXECUTION
           SET TILLS              = (SELECT COUNT(*) FROM #TILLS),
               SERVER_CASH_NUMBER = @SERVER_CASH,
               TILL_LIST          = STUFF((SELECT ',' + CAST(CASH_NUMBER AS VARCHAR(10))
                                           FROM #TILLS ORDER BY CASH_NUMBER
                                           FOR XML PATH(''), TYPE).value('.', 'VARCHAR(500)'), 1, 1, '')
        WHERE EXECUTION_ID = @EXECUTION_ID;

        SET @STATUS = 'RUNNING';

        SELECT CASH_NUMBER, TILL, NAME, IS_SERVER
        FROM #TILLS
        ORDER BY CASH_NUMBER;
    END TRY
    BEGIN CATCH
        SELECT @STATUS = 'ERROR', @MESSAGE = ERROR_MESSAGE();

        UPDATE dbo.PRICE_HOMOLOGATION_EXECUTION
           SET STATUS = @STATUS, END_DATE = GETDATE(), MESSAGE = @MESSAGE
        WHERE EXECUTION_ID = @EXECUTION_ID;

        IF APPLOCK_MODE(N'public', N'PRICE_HOMOLOGATION', N'Session') <> N'NoLock'
            EXEC sp_releaseapplock @Resource = N'PRICE_HOMOLOGATION', @LockOwner = N'Session';
        THROW;
    END CATCH
END
GO


/* -----------------------------------------------------------------------------
   PROCESS_PRICE_HOMOLOGATION
   Receives the prices of all tills (GET_HOMOLOGATION_PRICES of each till plus
   its CASH_NUMBER), compares them by SKU and price type, picks the winning price
   and decides the action. Only the SKUs with differences are saved.
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.PROCESS_PRICE_HOMOLOGATION') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.PROCESS_PRICE_HOMOLOGATION AS RETURN 0;');
GO
ALTER PROCEDURE dbo.PROCESS_PRICE_HOMOLOGATION
    @EXECUTION_ID INT,
    @PRICES       dbo.TT_PRICE_HOMOLOGATION_PRICE READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @TILL_LIST VARCHAR(500), @SERVER_CASH INT;

    SELECT @TILL_LIST = TILL_LIST, @SERVER_CASH = SERVER_CASH_NUMBER
    FROM dbo.PRICE_HOMOLOGATION_EXECUTION
    WHERE EXECUTION_ID = @EXECUTION_ID AND STATUS = 'RUNNING';

    IF @TILL_LIST IS NULL
        THROW 50011, N'The execution does not exist or is not running.', 1;

    -- Tills of the execution
    SELECT n.i.value('.', 'INT') AS CASH_NUMBER,
           'TILL' + n.i.value('.', 'VARCHAR(10)') AS TILL
    INTO #TILLS
    FROM (SELECT CAST('<i>' + REPLACE(@TILL_LIST, ',', '</i><i>') + '</i>' AS XML) AS X) AS l
    CROSS APPLY l.X.nodes('/i') AS n(i);

    IF EXISTS (SELECT 1 FROM @PRICES AS p
               WHERE NOT EXISTS (SELECT 1 FROM #TILLS AS t WHERE t.CASH_NUMBER = p.CASH_NUMBER))
        THROW 50012, N'@PRICES has a CASH_NUMBER that does not take part in this execution.', 1;

    -- Prices of each till grouped by SKU and price type
    SELECT SKU, PRICE_TYPE, CASH_NUMBER,
           COUNT(*) AS PRICE_ROWS,
           MAX(AMOUNT) AS AMOUNT,
           MAX(CASE WHEN MODIFIED_DATETIME IS NULL OR CREATED_DATETIME > MODIFIED_DATETIME
                    THEN CREATED_DATETIME ELSE MODIFIED_DATETIME END) AS PRICE_DATE
    INTO #PRICES
    FROM @PRICES
    GROUP BY SKU, PRICE_TYPE, CASH_NUMBER;

    -- Detail: one row per SKU, price type and till (PRICE_ROWS = 0: missing)
    SELECT k.SKU, k.PRICE_TYPE, t.CASH_NUMBER, t.TILL,
           ISNULL(p.PRICE_ROWS, 0) AS PRICE_ROWS, p.AMOUNT, p.PRICE_DATE
    INTO #DETAIL
    FROM (SELECT DISTINCT SKU, PRICE_TYPE FROM #PRICES) AS k
    CROSS JOIN #TILLS AS t
    LEFT JOIN #PRICES AS p
           ON p.SKU = k.SKU AND p.PRICE_TYPE = k.PRICE_TYPE AND p.CASH_NUMBER = t.CASH_NUMBER;

    -- SKUs with differences (missing, duplicated or different price)
    SELECT d.SKU, d.PRICE_TYPE,
           CAST(NULL AS DECIMAL(16,4))  AS WINNING_PRICE,
           CAST(NULL AS VARCHAR(200))   AS WINNING_TILL,
           CAST(NULL AS DATETIME)       AS WINNING_DATE,
           CAST(NULL AS VARCHAR(500))   AS TILLS_TO_UPDATE,
           CAST(NULL AS VARCHAR(1000))  AS ACTION
    INTO #COMPARISON
    FROM #DETAIL AS d
    GROUP BY d.SKU, d.PRICE_TYPE
    HAVING SUM(CASE WHEN d.PRICE_ROWS = 1 THEN 0 ELSE 1 END) > 0
        OR COUNT(DISTINCT ISNULL(d.AMOUNT, -1)) > 1;

    -- Winning price: most recent date, no tie and no duplicated prices
    UPDATE c
       SET WINNING_PRICE = w.AMOUNT,
           WINNING_TILL  = w.TILLS,
           WINNING_DATE  = m.MAX_DATE
    FROM #COMPARISON AS c
    CROSS APPLY (SELECT MAX(d.PRICE_DATE) AS MAX_DATE
                 FROM #DETAIL AS d
                 WHERE d.SKU = c.SKU AND d.PRICE_TYPE = c.PRICE_TYPE
                   AND d.PRICE_ROWS = 1 AND d.PRICE_DATE IS NOT NULL) AS m
    CROSS APPLY (SELECT COUNT(DISTINCT d.AMOUNT) AS AMOUNTS,
                        MIN(d.AMOUNT) AS AMOUNT,
                        STUFF((SELECT ',' + x.TILL FROM #DETAIL AS x
                               WHERE x.SKU = c.SKU AND x.PRICE_TYPE = c.PRICE_TYPE
                                 AND x.PRICE_ROWS = 1 AND x.PRICE_DATE = m.MAX_DATE
                               ORDER BY x.CASH_NUMBER
                               FOR XML PATH(''), TYPE).value('.', 'VARCHAR(200)'), 1, 1, '') AS TILLS
                 FROM #DETAIL AS d
                 WHERE d.SKU = c.SKU AND d.PRICE_TYPE = c.PRICE_TYPE
                   AND d.PRICE_ROWS = 1 AND d.PRICE_DATE = m.MAX_DATE) AS w
    WHERE w.AMOUNTS = 1
      AND NOT EXISTS (SELECT 1 FROM #DETAIL AS d
                      WHERE d.SKU = c.SKU AND d.PRICE_TYPE = c.PRICE_TYPE AND d.PRICE_ROWS > 1);

    -- Tills with an outdated price
    UPDATE c
       SET TILLS_TO_UPDATE = STUFF((SELECT ',' + d.TILL FROM #DETAIL AS d
                                    WHERE d.SKU = c.SKU AND d.PRICE_TYPE = c.PRICE_TYPE
                                      AND d.PRICE_ROWS = 1 AND d.AMOUNT <> c.WINNING_PRICE
                                    ORDER BY d.CASH_NUMBER
                                    FOR XML PATH(''), TYPE).value('.', 'VARCHAR(500)'), 1, 1, '')
    FROM #COMPARISON AS c
    WHERE c.WINNING_PRICE IS NOT NULL;

    -- Action
    UPDATE c
       SET ACTION = CASE
               WHEN dup.TILLS IS NOT NULL THEN 'REVIEW: duplicated price in ' + dup.TILLS
               WHEN c.WINNING_PRICE IS NULL THEN 'REVIEW: date tie with different prices'
               ELSE ISNULL('UPDATE ' + c.TILLS_TO_UPDATE + ' TO $'
                           + CONVERT(VARCHAR(30), CAST(c.WINNING_PRICE AS DECIMAL(16,2))), '')
                  + CASE WHEN c.TILLS_TO_UPDATE IS NOT NULL AND miss.TILLS IS NOT NULL THEN '; ' ELSE '' END
                  + ISNULL('REVIEW: missing in ' + miss.TILLS, '')
           END
    FROM #COMPARISON AS c
    OUTER APPLY (SELECT STUFF((SELECT ',' + d.TILL FROM #DETAIL AS d
                               WHERE d.SKU = c.SKU AND d.PRICE_TYPE = c.PRICE_TYPE AND d.PRICE_ROWS > 1
                               ORDER BY d.CASH_NUMBER
                               FOR XML PATH(''), TYPE).value('.', 'VARCHAR(500)'), 1, 1, '') AS TILLS) AS dup
    OUTER APPLY (SELECT STUFF((SELECT ',' + d.TILL FROM #DETAIL AS d
                               WHERE d.SKU = c.SKU AND d.PRICE_TYPE = c.PRICE_TYPE AND d.PRICE_ROWS = 0
                               ORDER BY d.CASH_NUMBER
                               FOR XML PATH(''), TYPE).value('.', 'VARCHAR(500)'), 1, 1, '') AS TILLS) AS miss;

    -- Save the SKUs with differences. If a SKU is written differently between
    -- tills, it is saved as it is written in the server till.
    BEGIN TRANSACTION;

    INSERT dbo.PRICE_HOMOLOGATION_DETAIL
           (EXECUTION_ID, SKU, PRICE_TYPE, CASH_NUMBER, PRICE_ROWS, PRICE, PRICE_DATE,
            WINNING_PRICE, WINNING_TILL, WINNING_DATE, ACTION, STATUS)
    SELECT @EXECUTION_ID,
           ISNULL(s.SKU, c.SKU),
           c.PRICE_TYPE,
           d.CASH_NUMBER,
           d.PRICE_ROWS,
           d.AMOUNT,
           d.PRICE_DATE,
           c.WINNING_PRICE,
           c.WINNING_TILL,
           c.WINNING_DATE,
           c.ACTION,
           CASE WHEN c.WINNING_PRICE IS NULL OR d.PRICE_ROWS <> 1 THEN 'REVIEW'
                WHEN d.AMOUNT <> c.WINNING_PRICE                  THEN 'PENDING'
                ELSE 'OK' END
    FROM #COMPARISON AS c
    JOIN #DETAIL AS d ON d.SKU = c.SKU AND d.PRICE_TYPE = c.PRICE_TYPE
    OUTER APPLY (SELECT TOP (1) p.SKU
                 FROM @PRICES AS p
                 WHERE p.CASH_NUMBER = @SERVER_CASH AND p.SKU = c.SKU AND p.PRICE_TYPE = c.PRICE_TYPE) AS s;

    UPDATE dbo.PRICE_HOMOLOGATION_EXECUTION
       SET DIFFERENT_SKUS = (SELECT COUNT(*) FROM #COMPARISON),
           SKUS_TO_UPDATE = (SELECT COUNT(*) FROM #COMPARISON WHERE TILLS_TO_UPDATE IS NOT NULL),
           SKUS_TO_REVIEW = (SELECT COUNT(*) FROM #COMPARISON WHERE ACTION LIKE '%REVIEW%')
    WHERE EXECUTION_ID = @EXECUTION_ID;

    COMMIT TRANSACTION;
END
GO


/* -----------------------------------------------------------------------------
   GET_HOMOLOGATION_CHANGES
   Prices to update in one till. The column order matches
   TT_PRICE_HOMOLOGATION_CHANGE (parameter of UPDATE_HOMOLOGATION_PRICES).
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.GET_HOMOLOGATION_CHANGES') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.GET_HOMOLOGATION_CHANGES AS RETURN 0;');
GO
ALTER PROCEDURE dbo.GET_HOMOLOGATION_CHANGES
    @EXECUTION_ID INT,
    @CASH_NUMBER  INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT SKU,
           PRICE_TYPE,
           WINNING_PRICE AS AMOUNT,
           WINNING_DATE  AS MODIFIED_DATETIME
    FROM dbo.PRICE_HOMOLOGATION_DETAIL
    WHERE EXECUTION_ID = @EXECUTION_ID
      AND CASH_NUMBER  = @CASH_NUMBER
      AND STATUS       = 'PENDING'
    ORDER BY SKU, PRICE_TYPE;
END
GO


/* -----------------------------------------------------------------------------
   INSERT_HOMOLOGATION_RESULTS
   Saves in the detail the result of UPDATE_HOMOLOGATION_PRICES of one till.
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.INSERT_HOMOLOGATION_RESULTS') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.INSERT_HOMOLOGATION_RESULTS AS RETURN 0;');
GO
ALTER PROCEDURE dbo.INSERT_HOMOLOGATION_RESULTS
    @EXECUTION_ID INT,
    @CASH_NUMBER  INT,
    @RESULTS      dbo.TT_PRICE_HOMOLOGATION_RESULT READONLY
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE d
       SET STATUS        = r.STATUS,
           ERROR_MESSAGE = LEFT(r.ERROR_MESSAGE, 4000),
           UPDATE_DATE   = GETDATE()
    FROM dbo.PRICE_HOMOLOGATION_DETAIL AS d
    JOIN @RESULTS AS r ON r.SKU = d.SKU AND r.PRICE_TYPE = d.PRICE_TYPE
    WHERE d.EXECUTION_ID = @EXECUTION_ID
      AND d.CASH_NUMBER  = @CASH_NUMBER
      AND d.STATUS       = 'PENDING';
END
GO


/* -----------------------------------------------------------------------------
   END_PRICE_HOMOLOGATION
   Closes the execution: counters and message. Releases the lock and returns
   the execution summary.
   @STATUS / @MESSAGE: only to close a canceled execution or one with an error
   (e.g. @STATUS = 'CANCELED' when a till cannot be reached).
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.END_PRICE_HOMOLOGATION') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.END_PRICE_HOMOLOGATION AS RETURN 0;');
GO
ALTER PROCEDURE dbo.END_PRICE_HOMOLOGATION
    @EXECUTION_ID INT,
    @STATUS       VARCHAR(20)    = NULL,
    @MESSAGE      NVARCHAR(4000) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @MODE VARCHAR(10), @WITH_ERROR INT, @DIFFERENT INT, @TO_UPDATE INT;
    SELECT @MODE = MODE FROM dbo.PRICE_HOMOLOGATION_EXECUTION WHERE EXECUTION_ID = @EXECUTION_ID;

    IF @STATUS IS NULL
    BEGIN
        SELECT @DIFFERENT  = COUNT(*),
               @TO_UPDATE  = SUM(CASE WHEN TO_UPDATE > 0 THEN 1 ELSE 0 END),
               @WITH_ERROR = SUM(CASE WHEN ERRORS > 0 THEN 1 ELSE 0 END)
        FROM (SELECT SUM(CASE WHEN STATUS IN ('PENDING', 'UPDATED', 'ERROR') THEN 1 ELSE 0 END) AS TO_UPDATE,
                     SUM(CASE WHEN STATUS = 'ERROR' THEN 1 ELSE 0 END) AS ERRORS
              FROM dbo.PRICE_HOMOLOGATION_DETAIL
              WHERE EXECUTION_ID = @EXECUTION_ID
              GROUP BY SKU, PRICE_TYPE) AS s;

        SET @STATUS = CASE WHEN ISNULL(@WITH_ERROR, 0) > 0 THEN 'PARTIAL' ELSE 'OK' END;
        SET @MESSAGE = CASE
            WHEN @DIFFERENT = 0            THEN N'Prices are homologated.'
            WHEN @MODE = 'REPORT'          THEN N'Report mode: no prices were changed.'
            WHEN @STATUS = 'PARTIAL'       THEN N'Some tills could not be updated. Check PRICE_HOMOLOGATION_DETAIL.'
            WHEN ISNULL(@TO_UPDATE, 0) = 0 THEN N'No prices to update. There are SKUs to review.'
            ELSE N'Prices updated.' END;

        UPDATE dbo.PRICE_HOMOLOGATION_EXECUTION
           SET SKUS_WITH_ERROR = ISNULL(@WITH_ERROR, 0)
        WHERE EXECUTION_ID = @EXECUTION_ID;
    END

    UPDATE dbo.PRICE_HOMOLOGATION_EXECUTION
       SET STATUS = @STATUS, MESSAGE = @MESSAGE, END_DATE = GETDATE()
    WHERE EXECUTION_ID = @EXECUTION_ID;

    IF APPLOCK_MODE(N'public', N'PRICE_HOMOLOGATION', N'Session') <> N'NoLock'
        EXEC sp_releaseapplock @Resource = N'PRICE_HOMOLOGATION', @LockOwner = N'Session';

    SELECT EXECUTION_ID, EXECUTION_DATE, END_DATE, MODE, STATUS, TILLS, DIFFERENT_SKUS,
           SKUS_TO_UPDATE, SKUS_TO_REVIEW, SKUS_WITH_ERROR, MESSAGE
    FROM dbo.PRICE_HOMOLOGATION_EXECUTION
    WHERE EXECUTION_ID = @EXECUTION_ID;
END
GO


/* -----------------------------------------------------------------------------
   GET_HOMOLOGATION_REPORT
   Table of the SKUs with differences: one price column and one date column
   per till (PRICE_TILL1, DATE_TILL1, ...), winning price, action and result.
   RESULT by SKU: PENDING / REVIEW / UPDATED / PARTIAL / ERROR.
   ----------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.GET_HOMOLOGATION_REPORT') IS NULL
    EXEC (N'CREATE PROCEDURE dbo.GET_HOMOLOGATION_REPORT AS RETURN 0;');
GO
ALTER PROCEDURE dbo.GET_HOMOLOGATION_REPORT
    @EXECUTION_ID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @TILL_LIST VARCHAR(500), @PRICE_COLUMNS NVARCHAR(MAX), @DATE_COLUMNS NVARCHAR(MAX), @SQL NVARCHAR(MAX);

    SELECT @TILL_LIST = TILL_LIST FROM dbo.PRICE_HOMOLOGATION_EXECUTION WHERE EXECUTION_ID = @EXECUTION_ID;

    IF @TILL_LIST IS NULL
    BEGIN
        -- Execution without tills (skipped or with an error)
        SELECT SKU, PRICE_TYPE, WINNING_PRICE, WINNING_TILL, WINNING_DATE, ACTION,
               CAST(NULL AS VARCHAR(20)) AS RESULT
        FROM dbo.PRICE_HOMOLOGATION_DETAIL
        WHERE 1 = 0;
        RETURN;
    END

    SELECT n.i.value('.', 'VARCHAR(10)') AS CASH_NUMBER
    INTO #TILLS
    FROM (SELECT CAST('<i>' + REPLACE(@TILL_LIST, ',', '</i><i>') + '</i>' AS XML) AS X) AS l
    CROSS APPLY l.X.nodes('/i') AS n(i);

    SET @PRICE_COLUMNS = STUFF((
        SELECT N', MAX(CASE WHEN d.CASH_NUMBER = ' + CASH_NUMBER
             + N' THEN d.PRICE END) AS ' + QUOTENAME(N'PRICE_TILL' + CASH_NUMBER)
        FROM #TILLS
        ORDER BY CAST(CASH_NUMBER AS INT)
        FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, N'');

    SET @DATE_COLUMNS = STUFF((
        SELECT N', MAX(CASE WHEN d.CASH_NUMBER = ' + CASH_NUMBER
             + N' THEN d.PRICE_DATE END) AS ' + QUOTENAME(N'DATE_TILL' + CASH_NUMBER)
        FROM #TILLS
        ORDER BY CAST(CASH_NUMBER AS INT)
        FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, N'');

    SET @SQL = N'SET ANSI_WARNINGS OFF;
        SELECT d.SKU, d.PRICE_TYPE, ' + @PRICE_COLUMNS + N',
               ''DIFFERENT'' AS PRICE_STATUS, ' + @DATE_COLUMNS + N',
               d.WINNING_PRICE, d.WINNING_TILL, d.WINNING_DATE, d.ACTION,
               CASE WHEN SUM(CASE WHEN d.STATUS = ''ERROR'' THEN 1 ELSE 0 END) > 0
                     AND SUM(CASE WHEN d.STATUS = ''UPDATED'' THEN 1 ELSE 0 END) > 0 THEN ''PARTIAL''
                    WHEN SUM(CASE WHEN d.STATUS = ''ERROR'' THEN 1 ELSE 0 END) > 0 THEN ''ERROR''
                    WHEN SUM(CASE WHEN d.STATUS = ''UPDATED'' THEN 1 ELSE 0 END) > 0
                     AND SUM(CASE WHEN d.STATUS = ''PENDING'' THEN 1 ELSE 0 END) > 0 THEN ''PARTIAL''
                    WHEN SUM(CASE WHEN d.STATUS = ''UPDATED'' THEN 1 ELSE 0 END) > 0 THEN ''UPDATED''
                    WHEN SUM(CASE WHEN d.STATUS = ''PENDING'' THEN 1 ELSE 0 END) > 0 THEN ''PENDING''
                    ELSE ''REVIEW'' END AS RESULT
        FROM dbo.PRICE_HOMOLOGATION_DETAIL AS d
        WHERE d.EXECUTION_ID = @EXECUTION_ID
        GROUP BY d.SKU, d.PRICE_TYPE, d.WINNING_PRICE, d.WINNING_TILL, d.WINNING_DATE, d.ACTION
        ORDER BY d.SKU, d.PRICE_TYPE;';

    EXEC sp_executesql @SQL, N'@EXECUTION_ID INT', @EXECUTION_ID = @EXECUTION_ID;
END
GO
