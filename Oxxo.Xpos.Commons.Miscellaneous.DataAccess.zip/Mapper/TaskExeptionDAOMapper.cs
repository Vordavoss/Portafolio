﻿using Oxxo.Framework.Integration.DAC;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Info;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using map = Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Constants.ConstantMapper;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Mapper
{
    public static class TaskExeptionDAOMapper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rdr"></param>
        /// <returns></returns>
        public static List<ExceptionTaskInfo> RetrieveExceptionTaskInfo(this SqlDataReader rdr)
        {
            try
            {
                List<ExceptionTaskInfo> exceptionTasks = new List<ExceptionTaskInfo>();

                while (rdr.Read())
                {
                    ExceptionTaskInfo exceptionTaskInfo = new ExceptionTaskInfo();

                    exceptionTaskInfo.ExceptionTaskId = rdr[map.EXCEPTION_TASK_ID].GetValInt();
                    exceptionTaskInfo.TaskName = rdr[map.TASK_NAME].GetValStr();
                    exceptionTaskInfo.AdminDate = rdr[map.ADMIN_DATE].GetValDatetime();
                    exceptionTaskInfo.ObjectType = rdr[map.OBJECT_TYPE].GetValStr();
                    exceptionTaskInfo.ObjectName = rdr[map.OBJECT_NAME].GetValStr();
                    exceptionTaskInfo.TraceLog = rdr[map.TRACE_LOG].GetValStr();
                    exceptionTaskInfo.DateStarExecution = rdr[map.DATE_START_EXECUTION].GetValDatetime();
                    exceptionTaskInfo.DateEndExecution = rdr[map.DATE_END_EXECUTION].GetValDatetime();
                    exceptionTaskInfo.ParameterList = rdr[map.PARAMETER_LIST].GetValStr();
                    exceptionTaskInfo.ProcessStatus = rdr[map.PROCESS_STATUS].GetValInt();
                    exceptionTaskInfo.ExecutionOrder = rdr[map.EXECUTION_ORDER].GetValInt();
                    exceptionTaskInfo.ExecutionPath = rdr[map.EXECUTION_PATH].GetValStr();
                    exceptionTaskInfo.ExecutionParameters = rdr[map.EXECUTION_PARAMETERS].GetValStr();
                    exceptionTaskInfo.RestartMachine = rdr[map.RESTART_MACHINE].GetValBool();
                    exceptionTaskInfo.IsActive = rdr[map.IS_ACTIVE].GetValBool();
                    exceptionTaskInfo.LCOUNT = rdr[map.LCOUNT].GetValInt();
                    exceptionTaskInfo.CreatedByOperatorId = rdr[map.CREATED_BY_OPERATOR_ID].GetValInt();
                    exceptionTaskInfo.CreatedDateTime = rdr[map.CREATED_DATETIME].GetValDatetime();
                    exceptionTaskInfo.ModifiedByOperatorId = rdr[map.MODIFIED_BY_OPERATOR_ID].GetValInt();
                    exceptionTaskInfo.ModifiedDateTime = rdr[map.MODIFIED_DATETIME].GetValDatetime();

                    exceptionTasks.Add(exceptionTaskInfo);
                }

                return exceptionTasks;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
