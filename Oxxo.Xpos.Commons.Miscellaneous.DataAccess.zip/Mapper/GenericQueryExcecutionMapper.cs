﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Mapper
{
    public class GenericQueryExcecutionMapper
    {
        public List<T> MapObjectGenericQueryExcecution<T>(SqlDataReader rdr)
        {
            List<T> taskList = new List<T>();
            while (rdr.Read())
            {
                if (typeof(T).FullName.Contains("System"))
                {
                    taskList.Add(rdr.GetFieldValue<T>(0));
                }
                else
                {
                    var d = typeof(T).GetProperties();
                    T ExceptionTask = (T)Activator.CreateInstance(typeof(T));
                    foreach (var item in d)
                    {
                        PropertyInfo name = typeof(T).GetProperty(d.First(x => x.Name == item.Name).Name);

                        if (!DBNull.Value.Equals(rdr[item.Name]))
                            name.SetValue(ExceptionTask, rdr[item.Name], null);

                    }
                    taskList.Add(ExceptionTask);
                }
            }

            return taskList;
        }
    }
}
