﻿using Oxxo.Framework.Integration.DAC;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using System.ComponentModel.Composition;
using System.Linq;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Entity;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Model;
using System.Data.Entity;
using System;
using System.Collections.Generic;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(IEodDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class EodDAO: AbstractDAO, IEodDAO
    {
        /// <summary>
        /// Get last eod from a specific machine
        /// </summary>
        /// <param name="serverName">the service name of machine</param>
        /// <param name="businessDate">the business date to work</param>
        /// <returns>Eod object</returns>
        public AS_END_DY_OX GetLastEndDay(string serverName = null, string businessDate = null)
        {
            AS_END_DY_OX result = null;
            using (MiscellaneousEntities context = GetDataContext(serverName))
            {
                if (string.IsNullOrEmpty(businessDate))
                {
                    BUSINESS_DAY currentBusinessDay = context.BUSINESS_DAY.SingleOrDefault(d => d.IS_ACTIVE);
                    if (currentBusinessDay != null)
                    {
                        result = context.AS_END_DY_OX
                            .Include(d => d.CODE)
                            .Include(d => d.BUSINESS_DAY).Where(d => d.BUSINESS_DAY.BUSINESS_DATE != currentBusinessDay.BUSINESS_DATE)
                            .OrderByDescending(d => d.ID_END_DY).FirstOrDefault();
                    }
                }
                else
                {
                    DateTime _businessDate = Convert.ToDateTime(businessDate);
                    BUSINESS_DAY BusinessDay = context.BUSINESS_DAY.SingleOrDefault(x => x.BUSINESS_DATE == _businessDate);
                    if (BusinessDay != null)
                    {
                        result = context.AS_END_DY_OX
                            .Include(d => d.CODE)
                            .Include(d => d.BUSINESS_DAY).Where(d => d.BUSINESS_DAY.BUSINESS_DATE < BusinessDay.BUSINESS_DATE)
                            .OrderByDescending(d => d.ID_END_DY).FirstOrDefault();
                    }
                }
            }
            return result;
        }
        /// <summary>
        /// Get an eod by business date
        /// </summary>
        /// <param name="businessDate">the businessDate of eod to retrive</param>
        /// <param name="serverName">the service name of machine</param>
        /// <returns>Eod object</returns>
        public AS_END_DY_OX GetEndDayByBusinessDate(DateTime businessDate,string serverName = null)
        {
            AS_END_DY_OX result = null;
            using (MiscellaneousEntities context = GetDataContext(serverName))
            {
                result = context.AS_END_DY_OX
                    .Include(d => d.CODE)
                    .Include(d => d.BUSINESS_DAY).SingleOrDefault(d => d.BUSINESS_DAY.BUSINESS_DATE == businessDate);
            }
            return result;
        }
        /// <summary>
        /// Get end-of-day reports that need to be printed
        /// </summary>
        /// <param name="businessDate">the businessDate of eod to retrive</param>
        /// <param name="serverName">the service name of machine</param>
        /// <returns>List of report info</returns>
        public List<GET_REPORTS_PRINTING_INFO_BY_BUSINESS_DATE_Result> GetReportsEodByBusinessDate(DateTime businessDate, string serverName = null)
        {
            List<GET_REPORTS_PRINTING_INFO_BY_BUSINESS_DATE_Result> result = null;
            using (MiscellaneousEntities context = GetDataContext(serverName))
            {
                result = context.Database.SqlQuery<GET_REPORTS_PRINTING_INFO_BY_BUSINESS_DATE_Result>(string.Format("GET_REPORTS_PRINTING_INFO_BY_BUSINESS_DATE @BUSINESS_DATE='{0}'", businessDate.ToString("yyyy-MM-dd"))).ToList();
            }
            return result;
        }
        /// <summary>
        /// Get the miscellaneous context from specific machine
        /// </summary>
        /// <param name="serverName">the service name of machine</param>
        /// <returns>Miscellaneous context object</returns>
        /// </param>
        private MiscellaneousEntities GetDataContext(string serverName)
        {
            if (serverName != null)
                return GetDataContext<MiscellaneousEntities>(serverName);
            else
                return GetDataContext<MiscellaneousEntities>();
        }
    }
}
