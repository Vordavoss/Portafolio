﻿using Oxxo.Framework.Integration.DAC;
using Oxxo.Framework.Subsystems.Logging;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Mapper;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Constants;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Info;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data;
using System.Data.SqlClient;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(ITaskExeptionDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class TaskExeptionDAO : AbstractDAO, ITaskExeptionDAO
    {
        #region Private Fields

        private ILogger log = LogManager.CreateLogger("IStoreExecutionDAO", null);

        #endregion

        #region Public Fields
        #endregion

        #region Public Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessDate"></param>
        /// <returns></returns>
        public List<ExceptionTaskInfo> GetTasks(DateTime businessDate)
        {
            List<ExceptionTaskInfo> exceptionTasks = new List<ExceptionTaskInfo>();

            using (LighWeightFactory db = new LighWeightFactory())
            {
                SqlDataReader rdr;

                try
                {
                    db.GetDataContext();

                    SqlCommand cmd = new SqlCommand(TaskExeptionConstants.SP_TASKS_EXCEPTIONS_NAME);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter(TaskExeptionConstants.PARAM_BUSINESS_DATE, SqlDbType.DateTime));
                    cmd.Parameters[TaskExeptionConstants.PARAM_BUSINESS_DATE].Value = businessDate;

                    rdr = db.ExecuteProcedure(cmd);

                    exceptionTasks = rdr.RetrieveExceptionTaskInfo();
                }
                catch (Exception ex)
                {
                    log.WriteError("Exception in MenuDAO", ex);
                }
                finally
                {
                    db.Close();
                }
            }

            return exceptionTasks;
        }
     
        #endregion
    }
}
