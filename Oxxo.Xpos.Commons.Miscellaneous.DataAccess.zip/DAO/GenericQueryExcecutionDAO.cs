﻿using Oxxo.Framework.Integration.DAC;
using Oxxo.Framework.Subsystems.Logging;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Mapper;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Info;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(IGenericQueryExcecutionDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class GenericQueryExcecutionDAO : AbstractDAO, IGenericQueryExcecutionDAO
    {
        ILogger log = LogManager.CreateLogger("IStoreExecutionDAO", null);
        private const string INITIAL_SQLPARAM_CHAR = "@";
        private SqlConnection cnn = null;

        /// <summary>
        /// Execute a generic Query from Database
        /// </summary>
        /// <typeparam name="T">Model to fill from database, must be with the same names than result</typeparam>
        /// <param name="args">Arguments to specify name, store procedure or command querty</param>
        /// <param name="logExecution">Log of work flow</param>
        /// <returns>Mapped generic model</returns>      
        public List<T> GenericQueryExcecution<T>(GenericQueryExcecutionArgs args, ref StringBuilder logExecution)
        {
            List<T> StoreExecutionList = new List<T>();
            logExecution.Append(string.Format(" => Start execution {0} from {1} => ", "GenericQueryExcecution", "IGenericQueryExcecutionDAO"));

            List<string> LogDescriptions = new List<string>
            {
                " => LocalConnectionLight Create",
                " => SqlCommand",
                " => Add Parameters",
                " => Execute CommandText {0}",
                " => ExceptionTaskInfo Create",
                " => StoreExecutionDAO MapObjectStoreExecution",
                " => Call Finalized Success execution ",
                " => StoreExecutionDAO CLOSE.",
                " => Exception in StoreExecutionDAO"
            };

            using (LighWeightFactory db = new LighWeightFactory())
            {
                SqlDataReader rdr;
                try
                {
                    db.GetDataContext();
                    log.WriteDebug(LogDescriptions[0]);
                    logExecution.Append(LogDescriptions[0]);

                    log.WriteDebug(LogDescriptions[1]);
                    logExecution.Append(LogDescriptions[1]);
                    SqlCommand cmd = new SqlCommand
                    {
                        CommandText = args.TypeCommand == CommandType.StoredProcedure ? args.StoreProcedureName : args.CommandTextExecution, // storeProcedureName,
                        CommandType = args.TypeCommand
                    };


                    if (args.Parameters != null)
                    {
                        log.WriteDebug(LogDescriptions[2]);
                        logExecution.Append(LogDescriptions[2]);

                        foreach (KeyValuePair<string, object> param in args.Parameters)
                        {
                            cmd.Parameters.AddWithValue(
                                  param.Key.Contains(INITIAL_SQLPARAM_CHAR) ? param.Key : string.Concat(INITIAL_SQLPARAM_CHAR, param.Key),
                                  param.Value);
                        }
                    }


                    log.WriteDebug(string.Format(LogDescriptions[3], args.TypeCommand == CommandType.StoredProcedure ? args.StoreProcedureName : args.CommandTextExecution));
                    logExecution.Append(string.Format(LogDescriptions[3], args.TypeCommand));

                    if (args.TypeCommand == CommandType.StoredProcedure)
                    {
                        rdr = db.ExecuteProcedure(cmd);
                    }
                    else
                    {
                        rdr = ExecuteProcedureloc(cmd, db, ref logExecution);
                    }

                    log.WriteDebug(LogDescriptions[4]);
                    logExecution.Append(string.Format(LogDescriptions[4]));
                    GenericQueryExcecutionMapper adp = new GenericQueryExcecutionMapper();

                    log.WriteDebug(LogDescriptions[5]);
                    logExecution.Append(string.Format(LogDescriptions[5]));

                    StoreExecutionList = adp.MapObjectGenericQueryExcecution<T>(rdr);
                    log.WriteDebug(LogDescriptions[6]);
                    logExecution.Append(string.Format(LogDescriptions[6]));
                    logExecution.Append(string.Format(LogDescriptions[7]));

                }
                catch (Exception ex)
                {
                    log.WriteError(LogDescriptions[8], ex);
                    logExecution.Append(string.Format("{0} {1}", LogDescriptions[8], ex.Message.ToString()));
                }

            }

            return StoreExecutionList;
        }

        /// <summary>
        /// ExecuteProcedureloc to execute withoit a type execution
        /// </summary>
        /// <param name="cmd">SqlCommand </param>
        /// <param name="db">Conection from LighWeightFactory</param>
        /// <returns>SqlDataReader </returns>
        private SqlDataReader ExecuteProcedureloc(SqlCommand cmd, LighWeightFactory db, ref StringBuilder logExecution)
        {
            List<string> LogDescriptions = new List<string>
            {
                " => Execution Open Connection",
                " => Execution Close Connection",
                " => Execution Open Connection",
                " => Execution Set Connection",
                " => Execution Execute Reader",
                " => Execution Execute Reader END",
                " => sqlex SQLException in LightDAO",
                " => SQLException InnerException in LightDAO ",
                " => SQLException Message in LightDAO",
                " => SQLException StackTrace in LightDAO ",
                " => sqlex Exception in Light",
                " => ExecuteProcedure Close"
            };


            SqlDataReader rdr = null;
            try
            {
                // 0. Open Connection
                log.WriteDebug(LogDescriptions[0]);
                logExecution.Append(LogDescriptions[0]);
                if (cnn == null)
                {
                    cnn = db.Open();
                }
                else
                {
                    log.WriteDebug(LogDescriptions[1]);
                    logExecution.Append(LogDescriptions[1]);
                    db.Dispose();
                    db.Close();
                    log.WriteDebug(LogDescriptions[2]);
                    logExecution.Append(LogDescriptions[2]);
                    cnn = db.Open();
                }

                // 1. Set the command object so it knows to execute a stored procedure
                log.WriteDebug(LogDescriptions[3]);
                logExecution.Append(LogDescriptions[3]);
                cmd.Connection = cnn;
                log.WriteDebug(LogDescriptions[4]);
                logExecution.Append(LogDescriptions[4]);
                // 2. Execute Command
                rdr = cmd.ExecuteReader();
                log.WriteDebug(LogDescriptions[5]);
                logExecution.Append(LogDescriptions[5]);

            }
            catch (SqlException sqlex)
            {
                log.WriteInfo(LogDescriptions[6]);
                logExecution.Append(LogDescriptions[6]);

                if (sqlex.InnerException != null)
                {
                    log.WriteInfo(LogDescriptions[7] + "[" + sqlex.InnerException.ToString() + "]");
                    logExecution.Append(LogDescriptions[7] + "[" + sqlex.InnerException.ToString() + "]");
                }
                if (sqlex.Message != null)
                {
                    log.WriteInfo(LogDescriptions[8] + "[" + sqlex.Message + "]");
                    logExecution.Append(LogDescriptions[8] + "[" + sqlex.Message + "]");
                }

                if (sqlex.StackTrace != null)
                {
                    log.WriteInfo(LogDescriptions[9] + "[" + sqlex.StackTrace + "]");
                    logExecution.Append(LogDescriptions[9] + "[" + sqlex.StackTrace + "]");
                }
            }
            catch (Exception ex)
            {
                log.WriteInfo("sqlex Exception in Light");
                logExecution.Append(" => sqlex Exception in Light");

                log.WriteInfo(LogDescriptions[10]);
                logExecution.Append(LogDescriptions[10]);
            }
            finally
            {
                // 3. Close Connection

                log.WriteDebug(LogDescriptions[11]);
                logExecution.Append(LogDescriptions[11]);

            }
            return rdr;
        }
    }
}
