﻿#region File Information
//===============================================================================
// Author: José Alfredo Estrada Meraz
// Date: 22/Dic/2022
// Comment: This class is used for access to data information about Cloud Management project.
//===============================================================================
#endregion File Information

using Oxxo.Framework.Integration.DAC;
using Oxxo.Framework.Subsystems.Logging;
using Oxxo.Xpos.Commons.DTO.Helper;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Constants;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Xpos.Modules.Sale.DTO.Info;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.Data.SqlClient;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(ICloudManagementDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class CloudManagementDAO : AbstractDAO, ICloudManagementDAO
    {
        #region Attributes

        private ILogger logger = LogManager.CreateLogger("CloudManagement");

        #endregion Attributes

        #region Public Implementation

        /// <summary>
        /// Save cut Z and Z on XposManagementCloud database.
        /// </summary>
        /// <param name="report">Cut information.</param>
        /// <returns>Operation result.</returns>
        public bool SaveCutXZ(OutXZInfo report)
        {
            bool result = false;

            try
            {
                this.logger.WriteInfo("Saving cut x, z.");
                string connStr = cleanConn(ConfigurationManager.ConnectionStrings[ConstantsCloudManagement.CONNECTION_STRING_MANAGEMENT_CLOUD].ConnectionString);
                using (var sqlConnection = new SqlConnection(connStr))
                {
                    var sqlParameters = new List<SqlParameter>
                    {
                        new SqlParameter("@DATA_JSON", JsonHelper.Serialize<OutXZInfo>(report))
                    };

                    sqlConnection.Open();
                    var sqlCommand = new SqlCommand();
                    sqlCommand.Connection = sqlConnection;
                    sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddRange(sqlParameters.ToArray());
                    sqlCommand.CommandText = ConstantsCloudManagement.SP_INSERT_CUT_XZ;
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                this.logger.WriteError("Error saving cut x, z: ", ex);
                throw;
            }

            return result;
        }

        /// <summary>
        /// Update key hash value used between XPOS and Middleware to communication.
        /// </summary>
        /// <param name="keyHash">Key hash value.</param>
        /// <returns>Operation result.</returns>
        public bool UpdateKeyHash(string keyHash)
        {
            bool result = false;

            try
            {
                this.logger.WriteInfo("Update key hash value.");

                string connStr = cleanConn(ConfigurationManager.ConnectionStrings[ConstantsCloudManagement.CONNECTION_STRING_MANAGEMENT_CLOUD].ConnectionString);
                using (var sqlConnection = new SqlConnection(connStr))
                {
                    var sqlParameters = new List<SqlParameter>
                    {
                        new SqlParameter("@HASH_KEY", keyHash)
                    };

                    sqlConnection.Open();
                    var sqlCommand = new SqlCommand();
                    sqlCommand.Connection = sqlConnection;
                    sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddRange(sqlParameters.ToArray());
                    sqlCommand.CommandText = ConstantsCloudManagement.SP_UPDATE_KEY_HASH;
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                this.logger.WriteError("Error updating key hash value: ", ex);
                throw;
            }

            return result;
        }

        /// <summary>
        /// Clean string connection of EF.
        /// </summary>
        /// <param name="strConn">Key hash value.</param>
        /// <returns>String Clean result.</returns>
        private string cleanConn(string strConn)
        {
            return strConn.Replace("metadata=res://*/;provider=System.Data.SqlClient;provider connection string=", string.Empty).Replace("\"",string.Empty);            
        }
        #endregion Public Implementation
    }
}