﻿using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Framework.Integration.DAC;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oxxo.Framework.Subsystems.Logging;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Constants;
using System.Configuration;
using Oxxo.Xpos.Commons.DTO.Helper;
using Oxxo.Xpos.Modules.Sale.DTO.Info;
using System.ComponentModel.Composition.Primitives;
using System.Data.SqlClient;
using System.Data;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(ISyncImgCloudMenuDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class SyncImgCloudMenuDAO : AbstractDAO, ISyncImgCloudMenuDAO
    {
        #region Attributes

        private ILogger logger = LogManager.CreateLogger("SyncImgCloudMenu");
     
        #endregion Attributes

        #region Public Implementation
        /// <summary>
        /// gets the value of the requested parameter from XposManagementCloud
        /// </summary>
        /// <returns></returns>
        public string GetSystemParamConfig(string code)
        {
            string result = string.Empty;

            string connStr = cleanConn(ConfigurationManager.ConnectionStrings[ConstantSyncImgCloudMenu.CONNECTION_STRING_MANAGEMENT_CLOUD].ConnectionString);

            using (var sqlConnection = new SqlConnection(connStr))
            {
                try
                {

                    this.logger.WriteInfo("GetSystemParamConfig obtiene el parametro:" + code);

                    var sqlParameters = new List<SqlParameter>
                    {
                        new SqlParameter(ConstantSyncImgCloudMenu.@CODE,code)
                    };

                    sqlConnection.Open();
                    using (var sqlCommand = new SqlCommand())
                    {
                        sqlCommand.Connection = sqlConnection;
                        sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                        sqlCommand.CommandText = ConstantSyncImgCloudMenu.GET_SYSTEMPARAMCONFIG_VALUE;
                        sqlCommand.Parameters.AddRange(sqlParameters.ToArray());

                        using (var rdr = sqlCommand.ExecuteReader())
                        {
                            if (rdr.Read())
                            {
                                result = rdr[ConstantSyncImgCloudMenu.VALUE].GetValStr();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.logger.WriteError("GetSystemParamConfig: ", ex);
                    throw;
                }
            }
            return result;
        }

        /// <summary>
        /// Check which images should be downloaded
        /// </summary>
        /// <param name="sXml"></param>
        /// <returns></returns>
        public DataTable GetWhichImagesShouldDownloaded(string sXml)
        {
            DataTable dtResult = new DataTable();
            string connStr = cleanConn(ConfigurationManager.ConnectionStrings["LocalConnection"].ConnectionString);

            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {                   
                    using (SqlCommand cmd = new SqlCommand(ConstantSyncImgCloudMenu.GET_IMAGES_SERVICES_DOWNLOAD, conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter(ConstantSyncImgCloudMenu.@Xml, System.Data.SqlDbType.Xml));
                        cmd.Parameters[ConstantSyncImgCloudMenu.@Xml].Value = sXml;
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            conn.Open();
                            adapter.Fill(dtResult);                           
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.WriteError("GetWhichImagesShouldDownloaded: ", ex);
            }
            return dtResult;
        }

        /// <summary>
        /// method to update downloaded images in the database
        /// </summary>
        /// <param name="sXml"></param>
        /// <returns></returns>
        public bool UpdateImagesDownload(string sXml)
        {
            string connStr = cleanConn(ConfigurationManager.ConnectionStrings["LocalConnection"].ConnectionString);

            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {

                    using (SqlCommand cmd = new SqlCommand(ConstantSyncImgCloudMenu.UPDATE_IMAGES_SERVICES_DOWNLOAD, conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(ConstantSyncImgCloudMenu.@Xml, SqlDbType.Xml).Value = sXml;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
                return true;
            }

            catch (Exception ex)
            {
                logger.WriteError("UpdateImagesDownload: ", ex);
                return false;
            }
        }

        /// <summary>
        /// Method to obtain the paths of the services menu logos
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetPathLogosMenuServices()
        {
            DataTable dtResult = new DataTable();
            string connStr = cleanConn(ConfigurationManager.ConnectionStrings["LocalConnection"].ConnectionString);

            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand(ConstantSyncImgCloudMenu.GET_PATH_LOCAL_LOGO_MENU_SERVICES, conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;                       
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            conn.Open();
                            adapter.Fill(dtResult);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.WriteError("GetPathLogosMenuServices: ", ex);

            }
            return dtResult;
        }


        /// <summary>
        /// Clean string connection of EF.
        /// </summary>
        /// <param name="strConn">Key hash value.</param>
        /// <returns>String Clean result.</returns>
        private string cleanConn(string strConn)
        {
            return strConn.Replace("metadata=res://*/;provider=System.Data.SqlClient;provider connection string=", string.Empty).Replace("\"", string.Empty);
        }
        #endregion Public Implementation
    }
}
