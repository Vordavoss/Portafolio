﻿using Oxxo.Framework.Integration.DAC;
using Oxxo.Xpos.Commons.Base.DataAccess.Model;
using Oxxo.Xpos.Commons.DTO.Entity;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(IAtaAlertDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class AtaAlertDAO : AbstractDAO, IAtaAlertDAO
    {
        #region Methods public

        public List<PositionWorkSchedule> GetShifts()
        {
            List<PositionWorkSchedule> list;

            using (CommonEntities context = GetDataContext<CommonEntities>())
            {
                var query = from pwsT in context.CO_SCH_PST_WRK
                            select pwsT;
                list = query.ToList<PositionWorkSchedule>();
            }

            return list;
        }

        public TimePeriod GetSegmentConfiguration(string segment)
        {
            TimePeriod obj;

            using (CommonEntities context = GetDataContext<CommonEntities>())
            {
                var query = from tp in context.TimePeriod
                            select tp;
                obj = query.FirstOrDefault(t => t.CODE == segment);
            }

            return obj;
        }

        public List<TimePeriod> GetAtaAlertWarnings(string timeGroup)
        {
            List<TimePeriod> list;

            using (CommonEntities context = GetDataContext<CommonEntities>())
            {
                var query = from TimeGroupPeriodLink in context.TimeGroupPeriodLink
                            join TimeGroup in context.TimeGroup on TimeGroupPeriodLink.TIME_GROUP_ID equals TimeGroup.TIME_GROUP_ID
                            join TimePeriod in context.TimePeriod on TimeGroupPeriodLink.TIME_PERIOD_ID equals TimePeriod.TIME_PERIOD_ID
                            where TimeGroup.NAME == timeGroup
                            select TimePeriod;
                list = query.ToList();
            }

            return list;
        }

        #endregion Methods public
    }
}
