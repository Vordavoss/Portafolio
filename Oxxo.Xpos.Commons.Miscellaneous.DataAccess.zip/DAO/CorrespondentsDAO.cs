﻿using Oxxo.Framework.Integration.DAC;
using Oxxo.Framework.Subsystems.Logging;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Model;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.Entity.Core;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(ICorrespondentsDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class CorrespondentsDAO : AbstractDAO, ICorrespondentsDAO
    {
        private ILogger logger = LogManager.CreateLogger("Sale");

        public Event GetTicketById(int EventId)
        {
            Event ev;

            using (MiscellaneousEntities context = GetDataContext<MiscellaneousEntities>())
            {
                ev = context.CO_EV.FirstOrDefault(f => f.EventId == EventId);                
            }

            return ev;
        }

        public List<Ticket> GetTicketByState(int CodeId, bool NotEqualOperator)
        {
            List<Ticket> ticketList = new List<Ticket>();
            
            //Cuando es !=
            if (NotEqualOperator)
            {
                this.GetTicketByStateNotEquals(CodeId, ref ticketList);
                return ticketList;
            }
            
            using (MiscellaneousEntities context = GetDataContext<MiscellaneousEntities>())
            {                
                //Este join se hace por que la tabla de events esta partida en dos para no romper el standard de ARTS                
                var eventCompletetList = context.CO_EV.Join(context.DTL_EV_OX, e => e.EventId, ed => ed.EventId, (e, ed) => new
                {
                    e,
                    ed
                }).
                    Where(w => w.e.StatusCodeId == CodeId);

                //Finalmente pasamos todo el resultado a tickets
                foreach (var item in eventCompletetList)
                {
                    ticketList.Add(new Ticket
                    {
                        ActualEndDateTimestamp =  item.e.ActualEndDateTimestamp,
                        ActualStartDateTimestamp = item.e.ActualStartDateTimestamp,
                        BusinessDayId = item.ed.BusinessDayId,
                        CREATED_BY_OPERATOR_ID = item.e.CREATED_BY_OPERATOR_ID,
                        CREATED_DATETIME =  item.e.CREATED_DATETIME,
                        Description =  item.e.Description,
                        EventDetailId = item.ed.EventDetailId,
                        EventId = item.e.EventId,
                        EventTypeCodeId = item.e.EventTypeCodeId,
                        IS_ACTIVE = item.e.IS_ACTIVE,
                        LCOUNT = item.e.LCOUNT,
                        MODIFIED_BY_OPERATOR_ID = item.e.MODIFIED_BY_OPERATOR_ID,
                        MODIFIED_DATETIME = item.e.MODIFIED_DATETIME,
                        Name = item.e.Name,
                        ReasonId =item.ed.ReasonId,
                        StatusCodeId = item.e.StatusCodeId,
                        TicketNumber = item.ed.TicketNumber,
                        TillId = item.ed.TillId
                    });
                }
            }

            return ticketList;
        }

        private void GetTicketByStateNotEquals(int CodeId, ref List<Ticket> ticketList)
        {
            using (MiscellaneousEntities context = GetDataContext<MiscellaneousEntities>())
            {
                //Este join se hace por que la tabla de events esta partida en dos para no romper el standard de ARTS                
                var eventCompletetList = context.CO_EV.Join(
                    context.DTL_EV_OX,
                    e => e.EventId,
                    ed => ed.EventId,
                    (e, ed) => new { e, ed }).
                    Where(w => w.e.StatusCodeId != CodeId);

                //Finalmente pasamos todo el resultado a tickets
                foreach (var item in eventCompletetList)
                {
                    ticketList.Add(new Ticket
                    {
                        ActualEndDateTimestamp = item.e.ActualEndDateTimestamp,
                        ActualStartDateTimestamp = item.e.ActualStartDateTimestamp,
                        BusinessDayId = item.ed.BusinessDayId,
                        CREATED_BY_OPERATOR_ID = item.e.CREATED_BY_OPERATOR_ID,
                        CREATED_DATETIME = item.e.CREATED_DATETIME,
                        Description = item.e.Description,
                        EventDetailId = item.ed.EventDetailId,
                        EventId = item.e.EventId,
                        EventTypeCodeId = item.e.EventTypeCodeId,
                        IS_ACTIVE = item.e.IS_ACTIVE,
                        LCOUNT = item.e.LCOUNT,
                        MODIFIED_BY_OPERATOR_ID = item.e.MODIFIED_BY_OPERATOR_ID,
                        MODIFIED_DATETIME = item.e.MODIFIED_DATETIME,
                        Name = item.e.Name,
                        ReasonId = item.ed.ReasonId,
                        StatusCodeId = item.e.StatusCodeId,
                        TicketNumber = item.ed.TicketNumber,
                        TillId = item.ed.TillId
                    });
                }
            }
        }

        public List<Ticket> GetTicketByState(int CodeId, DateTime DateFilter)
        {
            List<Ticket> ticketList = new List<Ticket>();

            using (MiscellaneousEntities context = GetDataContext<MiscellaneousEntities>())
            {
                //Este join se hace por que la tabla de events esta partida en dos para no romper el standard de ARTS                
                var eventCompletetList = context.CO_EV.Join(
                    context.DTL_EV_OX, e => e.EventId, ed => ed.EventId, (e, ed) => new
                {
                    e,
                    ed
                }).
                    Where(w => w.e.StatusCodeId == CodeId);

                //Finalmente pasamos todo el resultado a tickets
                foreach (var item in eventCompletetList)
                {
                    if (item.e.ActualStartDateTimestamp.Date == DateFilter.Date)
                    {
                        ticketList.Add(new Ticket
                        {
                            ActualEndDateTimestamp = item.e.ActualEndDateTimestamp,
                            ActualStartDateTimestamp = item.e.ActualStartDateTimestamp,
                            BusinessDayId = item.ed.BusinessDayId,
                            CREATED_BY_OPERATOR_ID = item.e.CREATED_BY_OPERATOR_ID,
                            CREATED_DATETIME = item.e.CREATED_DATETIME,
                            Description = item.e.Description,
                            EventDetailId = item.ed.EventDetailId,
                            EventId = item.e.EventId,
                            EventTypeCodeId = item.e.EventTypeCodeId,
                            IS_ACTIVE = item.e.IS_ACTIVE,
                            LCOUNT = item.e.LCOUNT,
                            MODIFIED_BY_OPERATOR_ID = item.e.MODIFIED_BY_OPERATOR_ID,
                            MODIFIED_DATETIME = item.e.MODIFIED_DATETIME,
                            Name = item.e.Name,
                            ReasonId = item.ed.ReasonId,
                            StatusCodeId = item.e.StatusCodeId,
                            TicketNumber = item.ed.TicketNumber,
                            TillId = item.ed.TillId
                        });
                    }
                }
            }

            return ticketList;
        }


        public void RegisterTicket(Event ev, EventDetail ed)
        {
            using (var context = base.GetDataContext<MiscellaneousEntities>())
            {   
                ev.EventId = (int)base.NextSequenceValue<Int64>(context, "Event_SEQ");
                ed.EventId = ev.EventId;
                ed.EventDetailId =  (int)base.NextSequenceValue<Int64>(context, "EventDetail_SEQ");
                context.CO_EV.Add(ev);
                context.DTL_EV_OX.Add(ed);
                context.SaveChanges();
            }
        }

        public void UpdateTicket(Event ev, EventDetail ed)
        {
            using (var context = base.GetDataContext<MiscellaneousEntities>())
            {
                context.Entry(ev).State = System.Data.Entity.EntityState.Modified;
                context.Entry(ed).State = System.Data.Entity.EntityState.Modified;
                
                try
                {
                    context.SaveChanges();
                }
                catch (OptimisticConcurrencyException ocException)
                {
                    logger.WriteError("Unexpected error executing CorrespondentsDAO.UpdateTicket().", ocException);                  
                    var objectContext = ((IObjectContextAdapter)context).ObjectContext;
                    objectContext.Refresh(
                        System.Data.Entity.Core.Objects.RefreshMode.ClientWins,
                        context.CO_EV);
                    objectContext.Refresh(
                        System.Data.Entity.Core.Objects.RefreshMode.ClientWins,
                        context.DTL_EV_OX);
                    objectContext.SaveChanges();
                }
                
                
            }
        }
    }
}
