﻿using Oxxo.Framework.Integration.DAC;
using Oxxo.Xpos.Commons.Base.DataAccess.Model;
using Oxxo.Xpos.Commons.DTO.Entity;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Model;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(IAlertsDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class AlertsDAO: AbstractDAO, IAlertsDAO
    {
        int PRICE_CHANGES = 18;
        int PROMOS = 3;
        public AlertPropertyValue GetAlertValuesByCode(string code)
        {
            AlertPropertyValue value = null;

            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                value = entities.CO_ALRT_PRY_OX.AsNoTracking().
                    Join(entities.VL_ALRT_PRY_OX, a => a.AlertPropertyCatalogId, va => va.AlertPropertyCatalogId, (a, va) => new { a, va })
                    .Where(w => w.a.AlertPropertyCode == code).Select(s => s.va).FirstOrDefault();
            }

            return value;
        }

        public Dictionary<string, AlertPropertyValue> GetAlertValuesByCode()
        {
           Dictionary<string, AlertPropertyValue> dicValues = new Dictionary<string,AlertPropertyValue>();

            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                var values = entities.CO_ALRT_PRY_OX.AsNoTracking().
                    Join(entities.VL_ALRT_PRY_OX, a => a.AlertPropertyCatalogId, va => va.AlertPropertyCatalogId, 
                    (a, va) => new { a.AlertPropertyCode, va });

                foreach (var value in values)
                {
                    dicValues.Add(value.AlertPropertyCode, value.va);
                }
            }

            return dicValues;
        }

        public AlertConfiguration GetAlertConfigurationById(int id)
        {
            AlertConfiguration result = null;
            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                result = entities.ALRT_CNFG_OX.Where(x => x.AlertConfigurationId == id).FirstOrDefault();
            }
            return result;
        }
        public AlertConfiguration GetAlertConfigurationByCode(int code)
        {
            AlertConfiguration result = null;
            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                result = entities.ALRT_CNFG_OX.Where(x => x.AlertCodeTypeId == code).FirstOrDefault();
            }
            return result;
        }
        public List<AlertPropertyValue> GetPropertiesByConfiguration(AlertConfiguration config)
        {
            List<AlertPropertyValue> result = null;

            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                result = entities.VL_ALRT_PRY_OX.Where(x => x.AlertConfigurationId == config.AlertConfigurationId).ToList();
            }

            return result;
        }
        public List<PositionWorkSchedule> GetShifts()
        {
            List<PositionWorkSchedule> list = null;

            using (CommonEntities context = GetDataContext<CommonEntities>())
            {
                list = context.CO_SCH_PST_WRK.ToList();
            }

            return list;
        }
        public TimePeriod GetSegmentConfiguration(string segment)
        {
            TimePeriod obj;

            using (CommonEntities context = GetDataContext<CommonEntities>())
            {
                obj = context.TimePeriod.Where(x => x.CODE == segment).FirstOrDefault();
            }

            return obj;
        }
        public List<TimePeriod> GetAlertWarnings(int timegroup)
        {
            List<TimePeriod> list = null;

            using (CommonEntities context = GetDataContext<CommonEntities>())
            {
                list = (from TimeGroupPeriodLink in context.TimeGroupPeriodLink
                            join TimeGroup in context.TimeGroup on TimeGroupPeriodLink.TIME_GROUP_ID equals TimeGroup.TIME_GROUP_ID
                            join TimePeriod in context.TimePeriod on TimeGroupPeriodLink.TIME_PERIOD_ID equals TimePeriod.TIME_PERIOD_ID
                            where TimeGroup.TIME_GROUP_ID == timegroup
                            select TimePeriod).ToList();
            }

            return list;
        }
        public int GetTimeGroupId(string Code)
        {
            int TimeGroupId = 0;
            using (CommonEntities context = GetDataContext<CommonEntities>())
            {
                TimeGroup group = context.TimeGroup.Where(x => x.NAME == Code).FirstOrDefault();

                if (group != null)
                {
                    TimeGroupId = group.TIME_GROUP_ID;
                }
            }
            return TimeGroupId;
        }
        public int GetAlertConfigurationByCode(string code)
        {
            int result = 0;
            int codeId = this.GetCodeIdForCode(code);
            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                AlertConfiguration config = entities.ALRT_CNFG_OX.Where(
                    x => x.AlertCodeTypeId == codeId).FirstOrDefault();
                if (config != null)
                {
                    result = config.AlertConfigurationId;
                }
            }

            return result;
        }
        public double GetInitialTimeInterval(int AlertConfigurationId)
        {
            return double.Parse(this.GetPropertyValueForCode("INIDESP", AlertConfigurationId).AlertPropertyValue1);
        }

        /// <summary>
        /// Method that gets the initial time interval to display 
        /// the emerging price labels print alert message.
        /// </summary>
        /// <param name="AlertConfigurationId"></param>
        /// <returns></returns>
        public double GetEmergentsInitialTimeInterval(int AlertConfigurationId)
        {
            return double.Parse(this.GetPropertyValueForCode("INITIAL_EMERGENTE", AlertConfigurationId).AlertPropertyValue1);
        }

        /// <summary>
        /// Method that gets the interval of seconds to display
        /// the emerging price labels print alert message.
        /// </summary>
        /// <param name="AlertConfigurationId"></param>
        /// <returns></returns>
        public double GetEmergentsSecondsInterval(int AlertConfigurationId)
        {
            return double.Parse(this.GetPropertyValueForCode("CANTSEGS_EMERGENTE", AlertConfigurationId).AlertPropertyValue1);
        }


        public double GetNextTimeInterval(int AlertConfigurationId)
        {
            return double.Parse(this.GetPropertyValueForCode("PROXHORA", AlertConfigurationId).AlertPropertyValue1);
        }

        /// <summary>
        /// Method that gets the interval of seconds to display 
        /// the next emerging price labels print alert message.
        /// </summary>
        /// <param name="AlertConfigurationId"></param>
        /// <returns></returns>
        public double GetEmergentsNextTimeInterval(int AlertConfigurationId)
        {
            return double.Parse(this.GetPropertyValueForCode("INIDESP_EMERGENTE", AlertConfigurationId).AlertPropertyValue1);
        }

        public void SetPosponedAlertInfo(int AlertConfigurationId)
        {
            this.SetNextDateHour(AlertConfigurationId);
            int posponedCount = int.Parse(this.GetPropertyValueForCode("POSPONER", AlertConfigurationId).AlertPropertyValue1);
            posponedCount++;
            if (posponedCount > 99)
            {
                posponedCount = 0;
            }
            this.SetPosponedAlertInfo(AlertConfigurationId, posponedCount.ToString());
        }

        /// <summary>
        /// Method that increments the counter of how many times it has been postponed 
        /// the emerging price labels print alert message.
        /// </summary>
        /// <param name="AlertConfigurationId"></param>
        public void SetEmergentsPosponedAlertInfo(int AlertConfigurationId)
        {
            int posponedCount = int.Parse(this.GetPropertyValueForCode("POSPONER_EMERGENTE", AlertConfigurationId).AlertPropertyValue1);
            posponedCount++;
            if (posponedCount > 99)
            {
                posponedCount = 0;
            }
            this.SetEmergentsPosponedAlertInfo(AlertConfigurationId, posponedCount.ToString());
        }
        public void SetPosponedAlertInfo(int AlertConfigurationId, string posponedCount)
        {
            this.SetPropertyValueForCode("POSPONER", AlertConfigurationId, posponedCount);
        }

        /// <summary>
        /// Method that sets the counter of how many times it has been postponed 
        /// the emerging price labels print alert message.
        /// </summary>
        /// <param name="AlertConfigurationId"></param>
        /// <param name="posponedCount"></param>
        public void SetEmergentsPosponedAlertInfo(int AlertConfigurationId, string posponedCount)
        {
            this.SetPropertyValueForCode("POSPONER_EMERGENTE", AlertConfigurationId, posponedCount);
        }
        public void SetNextDateHour(int AlertConfigurationId)
        {
            DateTime now = DateTime.Now;
            int cantsecs = int.Parse(this.GetPropertyValueForCode("CANTSEGS", AlertConfigurationId).AlertPropertyValue1);
            int seconds = (int)now.TimeOfDay.TotalSeconds;

            string result = (seconds + cantsecs).ToString();
            string date = now.ToString("dd/MM/yyyy");

            this.SetPropertyValueForCode("PROXFECHA", AlertConfigurationId, date);
            this.SetPropertyValueForCode("PROXHORA", AlertConfigurationId, result);
        }
        public void SetSecondsInterval(int interval, int AlertConfigurationId)
        {
            this.SetPropertyValueForCode("CANTSEGS", AlertConfigurationId, interval.ToString());
        }
        public string GetAlertMessage(int AlertConfigurationId)
        {
            return this.GetPropertyValueForCode("MENSAJE", AlertConfigurationId).AlertPropertyValue1;
        }

        /// <summary>
        /// Method that gets the text info to display 
        /// the emerging price labels print alert message.
        /// </summary>
        /// <param name="AlertConfigurationId"></param>
        /// <returns></returns>
        public string GetAlertEmergentMessage(int AlertConfigurationId)
        {
            return this.GetPropertyValueForCode("MENSAJE_EMERGENTE", AlertConfigurationId).AlertPropertyValue1;
        }
        public AlertPropertyValue GetPropertyValueForCode(string code, int alertConfigurationId)
        {
            AlertPropertyValue value = null;
            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                value = (from apv in entities.VL_ALRT_PRY_OX
                         join apc in entities.CO_ALRT_PRY_OX
                        on apv.AlertPropertyCatalogId equals apc.AlertPropertyCatalogId
                        where apc.AlertPropertyCode == code && apv.AlertConfigurationId == alertConfigurationId
                        select apv).FirstOrDefault();
            }

            return value;
        }
        public bool SetPropertyValueForCode(string code, int alertConfigurationId, string value)
        {
            int result = 0;
            using (MiscellaneousEntities entities = GetDataContext<MiscellaneousEntities>())
            {
                AlertPropertyValue val = (from apv in entities.VL_ALRT_PRY_OX
                                          join apc in entities.CO_ALRT_PRY_OX
                        on apv.AlertPropertyCatalogId equals apc.AlertPropertyCatalogId
                        where apc.AlertPropertyCode == code && apv.AlertConfigurationId == alertConfigurationId
                        select apv).FirstOrDefault();

                if (val != null)
                {
                    val.AlertPropertyValue1 = value;
                    val.LCOUNT++;
                    val.MODIFIED_BY_OPERATOR_ID = 1;
                    val.MODIFIED_DATETIME = DateTime.Now;

                    result = entities.SaveChanges();
                }
            }

            return result > 0;
        }
        private int GetCodeIdForCode(string code)
        {
            int result = 0;
            using (CommonEntities entities = GetDataContext<CommonEntities>())
            {
                Code c = entities.CODE.Where(x => x.NAME == code).FirstOrDefault();
                if (c != null)
                {
                    result = c.CODE_ID;
                }
            }
            return result;
        }

        public List<CO_LB_PRT_OX> GetLabelsToPrint()
        {
            List<CO_LB_PRT_OX> list = new List<CO_LB_PRT_OX>();
            using (CommonEntities entities = GetDataContext<CommonEntities>())
            {
                DateTime today = DateTime.Now;
                List<CO_LB_PRT_OX> priceChanges = entities.CO_LB_PRT_OX.Where(x => x.ID_MV == PRICE_CHANGES && x.FL_LB_PRT_END == false  && today.CompareTo(x.DT_LB_PRT_SRT) >= 0 && today.CompareTo(x.DT_LB_PRT_END) == -1).ToList();
                List<CO_LB_PRT_OX> promos = entities.CO_LB_PRT_OX.Where(x => x.ID_MV == PROMOS && x.FL_LB_PRT_SRT == false  && x.FL_LB_PRT_END == false && today.CompareTo(x.DT_LB_PRT_END) == -1).ToList();
                if (priceChanges != null && priceChanges.Count > 0) 
				{
                    list.AddRange(priceChanges.Where(x=> Math.Floor((x.DT_LB_PRT_SRT - today).TotalDays) <= 1).ToList());
                }
                if (promos != null && promos.Count > 0)
                {
                    list.AddRange(promos.Where(x => Math.Floor((x.DT_LB_PRT_SRT - today).TotalDays) <= 1).ToList());
                }
            }

            return list;
        }
    }
}
