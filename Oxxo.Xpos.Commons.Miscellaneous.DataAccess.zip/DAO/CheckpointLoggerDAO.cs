﻿#region File Information
//===============================================================================
// Author: Angel López
// Date: 27/Agosto/2021
// Comment: This class is used to set data to the service XposCheckpointLogger
//===============================================================================
// Change Log
//===============================================================================
// Author: 
// Date: 
// Comments: 
//===============================================================================
#endregion File Information

using Oxxo.Framework.Integration.DAC;
using Oxxo.Framework.Subsystems.Logging;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Contract.DAO;
using Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Model;
using Oxxo.Xpos.Commons.Miscellaneous.DTO.Entity;
using System;
using System.ComponentModel.Composition;
using System.Data.SqlClient;
using System.Linq;
using Newtonsoft.Json;
using System.Net;
using System.IO;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.DAO
{
    [Export(typeof(ICheckpointLoggerDAO)), PartCreationPolicy(CreationPolicy.Shared)]
    public class CheckpointLoggerDAO : AbstractDAO, ICheckpointLoggerDAO
    {
        private ILogger log = LogManager.CreateLogger("CheckpointLoggerDAO");

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ParamName">Name of parameter in SYSTEM_PARAM_CATALOG</param>
        /// <param name="json">Json to post</param>
        /// <returns></returns>
        public bool CheckpointLoggerPost(string ParamName, string json)
        {
            bool Result = false;
            HttpWebResponse response = null;
            Stream strReader = null;
            HttpWebRequest request = null;

            string Config = "";
            CheckpointLogger checkpointLogger = new CheckpointLogger();

            if (ParamName.Any())
            {
                using (MiscellaneousEntities context = GetDataContext<MiscellaneousEntities>())
                {
                    SqlParameter pAram = new SqlParameter(Constants.ConstantBinnacle.SYSTEM_PARAM_NAME, ParamName);

                    Config = RetrieveWithProcedure<string>(context, Constants.ConstantBinnacle.GET_CHECKPOINT_LOGGER_CONFIG, pAram);
                    checkpointLogger = JsonConvert.DeserializeObject<CheckpointLogger>(Config);
                    log.WriteDebug("Obtencion de configuracion de servicio CheckpointLoggerDAO: " + Config);
                }

                if (checkpointLogger.Url.Any())
                {
                    string http = (checkpointLogger.Https ? "Https://" : "Http://");
                    string puerto = ":" + checkpointLogger.AssignedPort;
                    string Url = http + checkpointLogger.Url + puerto + checkpointLogger.Method;
                    request = (HttpWebRequest)WebRequest.Create(Url);
                    request.Method = "POST";
                    request.ContentType = "application/json";
                    request.Accept = "application/json";
                    request.KeepAlive = false;

                    using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                    {
                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }

                    try
                    {
                        using (response = (HttpWebResponse)request.GetResponse())
                        {
                            if (response.StatusCode != HttpStatusCode.OK) return false;
                            using (strReader = response.GetResponseStream())
                            {
                                if (strReader == null) return false;
                                using (StreamReader objReader = new StreamReader(strReader))
                                {
                                    string responseBody = objReader.ReadToEnd();
                                    return Convert.ToBoolean(responseBody);
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        log.WriteError("Unespected error executing " + Constants.ConstantBinnacle.GET_CHECKPOINT_LOGGER_CONFIG + " on try to post to CheckpointLogger", e);
                        throw new InvalidOperationException("Unespected error executing " + Constants.ConstantBinnacle.GET_CHECKPOINT_LOGGER_CONFIG, e);
                    }
                }
            }

            return Result;

        }
    }
}
