﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Constants
{
    internal class ConstantSyncImgCloudMenu
    {

        /// <summary>
        /// Connection string name of XposManagementCloud database.
        /// </summary>
        public const string CONNECTION_STRING_MANAGEMENT_CLOUD = "OxxoManagementCloudConnection";

        /// <summary>
        /// Store procedure to get configurations
        /// </summary>
        public const string GET_SYSTEMPARAMCONFIG_VALUE = "GET_SYSTEMPARAMCONFIG_VALUE";

        /// <summary>
        /// Store procedure to get path logos services
        /// </summary>
        public const string GET_PATH_LOCAL_LOGO_MENU_SERVICES = "GET_PATH_LOCAL_LOGO_MENU_SERVICES";

        /// <summary>
        /// Stored Procedure Check which images should be downloaded
        /// </summary>
        public const string GET_IMAGES_SERVICES_DOWNLOAD = "GET_IMAGES_SERVICES_DOWNLOAD";

        /// <summary>
        /// Stored Procedure Check which images should be downloaded
        /// </summary>
        public const string UPDATE_IMAGES_SERVICES_DOWNLOAD = "UPDATE_IMAGES_SERVICES_DOWNLOAD";

        public const string @CODE = "@CODE";

        public const string VALUE= "VALUE";

        public const string  @Xml ="@Xml";

    }
}
