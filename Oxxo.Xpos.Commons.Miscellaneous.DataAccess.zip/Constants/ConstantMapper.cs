﻿
namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Constants
{
    public class ConstantMapper
    {
        #region ExceptionTaskInfo Keys Fields

        public const string EXCEPTION_TASK_ID = "ID_TSK_EXCPN_END_DY";
        public const string TASK_NAME = "NM_TSK_EXCPN";
        public const string ADMIN_DATE = "DT_ADMN_EXE";
        public const string OBJECT_TYPE = "TY_OBJ_EXE";
        public const string OBJECT_NAME = "NM_OBJ_EXE";
        public const string TRACE_LOG = "DE_LOG";
        public const string DATE_START_EXECUTION = "DT_SRT_EXE";
        public const string DATE_END_EXECUTION = "DT_END_EXE";
        public const string PARAMETER_LIST = "NM_LST_PRMR";
        public const string PROCESS_STATUS = "SC_PCS";
        public const string EXECUTION_ORDER = "AM_ORD";
        public const string EXECUTION_PATH = "XM_URL";
        public const string EXECUTION_PARAMETERS = "XM_PRM";
        public const string RESTART_MACHINE = "RX_XPS";
        public const string IS_ACTIVE = "FL";
        public const string LCOUNT = "LCNT";
        public const string CREATED_BY_OPERATOR_ID = "ID_OPR_CRT";
        public const string CREATED_DATETIME = "TM_CRT";
        public const string MODIFIED_BY_OPERATOR_ID = "ID_OPR_MDY";
        public const string MODIFIED_DATETIME = "TM_MDY";
     
        #endregion
    }
}
