﻿#region File Information
//===============================================================================
// Author: José Alfredo Estrada Meraz
// Date: 22/Dic/2022
// Comment: This class is used to define all the constants.
//===============================================================================
#endregion File Information

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Constants
{
    public static class ConstantsCloudManagement
    {
        /// <summary>
        /// Store procedure to save cut X and Z in XposManagementCloud database.
        /// </summary>
        public const string SP_INSERT_CUT_XZ = "INSERT_CUT_XZ";

        /// <summary>
        /// Store procedure to update key hash value used between XPOS and Middleware to communication.
        /// </summary>
        public const string SP_UPDATE_KEY_HASH = "UPDATE_KEY_HASH_MIDDLEWARE_CLIENT";

        /// <summary>
        /// Connection string name of XposManagementCloud database.
        /// </summary>
        public const string CONNECTION_STRING_MANAGEMENT_CLOUD = "OxxoManagementCloudConnection";
    }
}