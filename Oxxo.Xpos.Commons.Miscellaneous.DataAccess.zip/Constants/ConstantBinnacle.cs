﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oxxo.Xpos.Commons.Miscellaneous.DataAccess.Constants
{
    public class ConstantBinnacle
    {
        public const string GET_CHECKPOINT_LOGGER_CONFIG = "GET_CHECKPOINT_LOGGER_CONFIG";
        public const string SYSTEM_PARAM_NAME = "@PARAMNAME";
    }
}
